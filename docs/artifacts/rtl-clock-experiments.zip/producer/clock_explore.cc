#include <filesystem>
#include <fstream>
#include <iostream>
#include <iterator>
#include <stdexcept>
#include <string>
#include <vector>

#include "absl/flags/flag.h"
#include "absl/flags/parse.h"
#include "absl/strings/str_cat.h"
#include "absl/strings/str_format.h"
#include "absl/strings/str_replace.h"
#include "google/protobuf/struct.pb.h"
#include "google/protobuf/text_format.h"
#include "google/protobuf/util/json_util.h"
#include "rtl/producer/producer.h"

ABSL_FLAG(std::string, phase, "prepare", "prepare or collect");
namespace {
namespace fs = std::filesystem;
using namespace sfu::rtl;
using google::protobuf::Struct;
const fs::path kRoot = "rtl/producer/clock_search";
std::string Read(const fs::path& path) {
  std::ifstream f(path);
  if (!f) throw std::runtime_error("cannot read " + path.string());
  return {(std::istreambuf_iterator<char>(f)), {}};
}
void Write(const fs::path& path, const std::string& value) {
  fs::create_directories(path.parent_path());
  std::ofstream f(path);
  f << value;
  if (!f) throw std::runtime_error("cannot write " + path.string());
}
void Copy(const fs::path& source, const fs::path& destination,
          fs::copy_options options = fs::copy_options::overwrite_existing) {
  if (fs::exists(destination))
    fs::permissions(destination, fs::perms::owner_write, fs::perm_options::add);
  fs::copy_file(source, destination, options);
  fs::permissions(destination, fs::perms::owner_write, fs::perm_options::add);
}
template <class T>
T Proto(const fs::path& path) {
  T v;
  if (!google::protobuf::TextFormat::ParseFromString(Read(path), &v))
    throw std::runtime_error("invalid specification " + path.string());
  return v;
}
template <class T>
void Save(const fs::path& path, const T& v) {
  std::string s;
  google::protobuf::TextFormat::PrintToString(v, &s);
  Write(path, s);
}
Struct Json(const fs::path& path) {
  Struct s;
  if (!google::protobuf::util::JsonStringToMessage(Read(path), &s).ok())
    throw std::runtime_error("invalid report " + path.string());
  return s;
}
std::string JsonText(const Struct& value) {
  std::string text;
  google::protobuf::util::JsonPrintOptions options;
  options.add_whitespace = true;
  if (!google::protobuf::util::MessageToJsonString(value, &text, options).ok())
    throw std::runtime_error("cannot encode report");
  return text;
}
struct Trial {
  std::string name, why;
  int period;
  NumericalDesign d;
  Implementation i;
};
// This list records hypotheses chosen from stage paths. Preparing the list does
// not run a Cartesian search; individual Bazel targets are measured as needed.
std::vector<Trial> Trials() {
  auto d = Proto<NumericalDesign>("rtl/producer/fixtures/exp2.textproto");
  auto i =
      Proto<Implementation>("rtl/producer/fixtures/column_local.textproto");
  std::vector<Trial> out;
  auto add = [&](std::string name, int period, int latency, bool rows,
                 int prefix_macs, std::string why) {
    Trial t{name, why, period, d, i};
    t.d.set_register_stages(latency);
    t.i.set_name(name);
    t.i.set_compression(rows ? ROW_TREE : COLUMN_GREEDY);
    if (latency == 5) {
      auto* p = t.i.mutable_pipeline();
      p->set_operand_stage(1);
      p->set_first_cut_stage(2);
      p->set_first_result_stage(3);
      p->set_second_cut_stage(4);
    }
    if (prefix_macs) {
      for (auto* mac : {t.i.mutable_first_mac(), t.i.mutable_second_mac()}) {
        if (mac == t.i.mutable_second_mac() && prefix_macs == 1) continue;
        mac->mutable_low_adder()->set_kind(PREFIX);
        mac->mutable_high_adder()->set_kind(PREFIX);
      }
    }
    out.push_back(std::move(t));
  };
  add("t1000_c4_ripple", 1000, 4, false, 0,
      "Reproduce the four-cycle default.");
  add("t800_c4_ripple", 800, 4, false, 0,
      "First MAC had 89 ps slack at 1 ns; remap at 800 ps.");
  add("t800_c4_first_prefix", 800, 4, false, 1,
      "Shorten the limiting first MAC carry path; preserve second-MAC ripple.");
  add("t800_c5_ripple", 800, 5, false, 0,
      "Alternatively split the first MAC and retain ripple throughout.");
  add("t700_c4_ripple", 700, 4, false, 0,
      "Establish the unmodified four-cycle failure at the tighter target.");
  add("t700_c4_prefix", 700, 4, false, 2,
      "Both MACs lose sufficient timing margin; try faster carry throughout.");
  add("t700_c5_ripple", 700, 5, false, 0,
      "First MAC split leaves the second compression/low-carry path limiting.");
  add("t700_c5_rows", 700, 5, true, 0,
      "Whole-row grouping had more compression-stage timing margin in the "
      "six-cycle study, at the cost of a larger stored heap.");
  add("t800_c4_unified_prefix", 800, 4, false, 1,
      "The first MAC still misses 20 ps with separate low/upper prefix sums. "
      "Use one prefix network across the unregistered sum.");
  out.back().i.mutable_first_mac()->set_unified_completion(true);
  add("t800_c4_unified_hybrid", 800, 4, false, 0,
      "Allow early low columns to ripple; prefix only the upper suffix of "
      "the unified first-MAC sum.");
  auto* mac = out.back().i.mutable_first_mac();
  mac->set_unified_completion(true);
  mac->mutable_high_adder()->set_kind(HYBRID);
  mac->mutable_high_adder()->set_ripple_bits(8);
  add("t700_c5_low_block8", 700, 5, false, 0,
      "R4 low-column addition misses 40.53 ps; use block lookahead there "
      "without changing the other three carry networks or the stored heap.");
  mac = out.back().i.mutable_second_mac();
  mac->mutable_low_adder()->set_kind(BLOCK_LOOKAHEAD);
  mac->mutable_low_adder()->set_block_bits(8);
  add("t700_c5_cut15", 700, 5, false, 0,
      "R4 misses 40.53 ps while R5 has 48.23 ps slack. Move two unresolved "
      "low columns across R4, keeping the numerical drop at 17.");
  out.back().i.mutable_second_mac()->set_resolved_columns(15);
  add("t700_c5_cut13", 700, 5, false, 0,
      "The 15-column cut recovers 24 ps but still misses 16.61 ps; R5 retains "
      "49.62 ps slack. Move two more unresolved columns across R4.");
  out.back().i.mutable_second_mac()->set_resolved_columns(13);
  add("t700_c6_product_cut", 700, 6, false, 0,
      "Alternatively insert a second-MAC product-row register before "
      "compression. This isolates selection delay while retaining ripple.");
  auto* p = out.back().i.mutable_pipeline();
  p->set_operand_stage(1);
  p->set_first_cut_stage(2);
  p->set_first_result_stage(3);
  p->set_second_cut_stage(5);
  out.back().i.mutable_second_mac()->set_product_register_stage(4);
  Trial compressed = out.back();
  compressed.name = "t700_c6_compress3";
  compressed.i.set_name(compressed.name);
  compressed.why =
      "The added product bank has 372.43 ps slack and stores 189 bits. "
      "Move three compressor layers before it to reduce stored information.";
  compressed.i.mutable_second_mac()
      ->set_compression_layers_before_product_register(3);
  out.push_back(std::move(compressed));
  for (int layers : {4, 5}) {
    Trial later = out.back();
    later.name = absl::StrCat("t700_c6_compress", layers);
    later.i.set_name(later.name);
    later.why =
        "After three layers, R4 still has 164.37 ps slack. Complete another "
        "one or two layers before that register to reduce stored information.";
    later.i.mutable_second_mac()
        ->set_compression_layers_before_product_register(layers);
    out.push_back(std::move(later));
  }
  Trial full = out.back();
  full.name = "t700_c6_full_compress";
  full.i.set_name(full.name);
  full.why =
      "After five layers R4 has 82.78 ps slack. Test the natural endpoint: "
      "finish compression before R4 and leave low-column carry for R5.";
  full.i.mutable_second_mac()->set_compression_layers_before_product_register(
      0);
  out.push_back(std::move(full));
  return out;
}
void Prepare() {
  std::string build =
      "load(\"//rtl/producer:generate.bzl\", \"polynomial_experiment\")\n\n";
  Struct plan;
  auto* list = (*plan.mutable_fields())["trials"].mutable_list_value();
  for (const auto& t : Trials()) {
    auto circuit = Lower(t.d, t.i);
    if (!circuit.ok() || !Verify(*circuit, 512).ok())
      throw std::runtime_error("invalid circuit " + t.name);
    Save(kRoot / (t.name + ".design.textproto"), t.d);
    Save(kRoot / (t.name + ".impl.textproto"), t.i);
    const std::string sdc = absl::StrReplaceAll(
        Read("rtl/producer/polynomial.sdc"),
        {{"# ASAP7 libraries use ps and fF. A 1000 ps period is a 1 GHz "
          "target.",
          "# Common IO/uncertainty/load; clock period in ps."},
         {"-period 1000", absl::StrCat("-period ", t.period)}});
    Write(kRoot / absl::StrCat("clock_", t.period, ".sdc"), sdc);
    absl::StrAppendFormat(
        &build,
        "polynomial_experiment(name=\"%s\", design=\"%s.design.textproto\", "
        "implementation=\"%s.impl.textproto\", period_ps=%d, "
        "sdc=\"clock_%d.sdc\", tags=[\"manual\"])\n",
        t.name, t.name, t.name, t.period, t.period);
    auto& fields =
        *list->add_values()->mutable_struct_value()->mutable_fields();
    fields["name"].set_string_value(t.name);
    fields["hypothesis"].set_string_value(t.why);
    fields["period_ps"].set_number_value(t.period);
    fields["cycles"].set_number_value(t.d.register_stages());
  }
  Write(kRoot / "BUILD.bazel", build);
  Write(kRoot / "plan.json", JsonText(plan));
}
void Collect() {
  Struct result;
  auto* list = (*result.mutable_fields())["trials"].mutable_list_value();
  std::string table =
      "| Trial | Period (ps) | Cycles | Area (µm²) | Slack (ps) | Power (mW) | "
      "FFs |\n|---|---:|---:|---:|---:|---:|---:|\n";
  for (const auto& t : Trials()) {
    const auto base = fs::path("bazel-bin") / kRoot / t.name;
    if (!fs::exists(base / "reports/summary.json")) continue;
    const auto generated = fs::path(base.string() + "_generated");
    const auto circuit = Proto<Circuit>(generated / "circuit.textproto");
    auto expected = Lower(t.d, t.i);
    if (!expected.ok() ||
        circuit.SerializeAsString() != expected->SerializeAsString() ||
        Read(generated / "sfu_poly.sv") != EmitSystemVerilog(*expected))
      throw std::runtime_error("stale circuit " + t.name);
    for (auto log : {"simulation.log", "gate_simulation.log"})
      if (Read(base / log).find("PASS:") == std::string::npos)
        throw std::runtime_error("unchecked simulation " + t.name);
    auto report = Json(base / "reports/summary.json");
    const auto& f = report.fields();
    if (f.at("clock_period_ps").number_value() != t.period)
      throw std::runtime_error("mapping period mismatch " + t.name);
    auto stats = Json(base / "mapped/statistics.json");
    int ff = 0;
    for (const auto& [cell, count] : stats.fields()
                                         .at("design")
                                         .struct_value()
                                         .fields()
                                         .at("num_cells_by_type")
                                         .struct_value()
                                         .fields())
      if (cell.find("DFF") != std::string::npos) ff += count.number_value();
    const double area = f.at("cell_area_um2").number_value();
    const double slack = f.at("worst_setup_slack_ps").number_value();
    const double power = f.at("power")
                             .struct_value()
                             .fields()
                             .at("Total")
                             .struct_value()
                             .fields()
                             .at("total")
                             .number_value() *
                         1000;
    absl::StrAppendFormat(
        &table, "| %s | %d | %d | %.5f | %.2f | %.6f | %d |\n", t.name,
        t.period, t.d.register_stages(), area, slack, power, ff);
    auto& row = *list->add_values()->mutable_struct_value()->mutable_fields();
    row["measurement"].mutable_struct_value()->CopyFrom(report);
    row["name"].set_string_value(t.name);
    row["hypothesis"].set_string_value(t.why);
    row["cycles"].set_number_value(t.d.register_stages());
    row["flip_flops"].set_number_value(ff);
    const auto saved = kRoot / "results" / t.name;
    for (const auto& dir : {"generated", "mapped", "reports"})
      fs::create_directories(saved / dir);
    for (const auto& entry : fs::directory_iterator(generated))
      Copy(entry.path(), saved / "generated" / entry.path().filename(),
           fs::copy_options::overwrite_existing);
    for (auto filename : {"simulation.log", "gate_simulation.log", "lint.log"})
      Copy(base / filename, saved / filename,
           fs::copy_options::overwrite_existing);
    for (auto filename : {"netlist.v", "statistics.json", "metadata.json",
                          "synthesis.ys", "synthesis.log", "abc.constr"})
      Copy(base / "mapped" / filename, saved / "mapped" / filename,
           fs::copy_options::overwrite_existing);
    const auto library = kRoot / "results/asap7.lib";
    if (!fs::exists(library)) Copy(base / "mapped/asap7.lib", library);
    if (!fs::exists(saved / "mapped/asap7.lib"))
      fs::create_hard_link(library, saved / "mapped/asap7.lib");
    for (auto filename : {"summary.json", "timing_power.log", "analysis.tcl"})
      Copy(base / "reports" / filename, saved / "reports" / filename,
           fs::copy_options::overwrite_existing);
    Copy(kRoot / absl::StrCat("clock_", t.period, ".sdc"), saved / "clock.sdc",
         fs::copy_options::overwrite_existing);
    // The checked logs and activity-power report retain their trace hashes.
    // Keep simulators; regenerate raw waveforms only when inspecting activity.
    fs::remove(base / "rtl.vcd");
    fs::remove(base / "gate.vcd");
  }
  Write(kRoot / "results/comparison.md", table);
  Write(kRoot / "results/comparison.json", JsonText(result));
  Copy(kRoot / "plan.json", kRoot / "results/plan.json");
  for (const auto& file : {"producer.cc", "emit.cc", "schema.proto",
                           "generate.bzl", "clock_explore.cc"}) {
    fs::create_directories(kRoot / "results/sources");
    Copy(fs::path("rtl/producer") / file, kRoot / "results/sources" / file);
  }
  std::cout << table;
}
}  // namespace
int main(int argc, char** argv) {
  absl::ParseCommandLine(argc, argv);
  try {
    if (absl::GetFlag(FLAGS_phase) == "prepare")
      Prepare();
    else if (absl::GetFlag(FLAGS_phase) == "collect")
      Collect();
    else
      throw std::runtime_error("unknown phase");
  } catch (const std::exception& e) {
    std::cerr << e.what() << '\n';
    return 1;
  }
}
