#include <algorithm>
#include <array>
#include <string>
#include <vector>

#include "absl/strings/str_cat.h"
#include "absl/strings/str_format.h"
#include "absl/strings/str_replace.h"
#include "rtl/producer/producer.h"

namespace sfu::rtl {
namespace {
std::string Ref(uint32_t id) {
  return id < 2 ? absl::StrFormat("1'b%d", id) : absl::StrFormat("n%d", id);
}
std::string Escape(absl::string_view text) {
  return absl::StrReplaceAll(
      text, {{"&", "&amp;"}, {"<", "&lt;"}, {">", "&gt;"}, {"\"", "&quot;"}});
}
}  // namespace
std::string EmitSystemVerilog(const Circuit& c) {
  int address = 0;
  while ((1 << address) < c.design().table_size()) ++address;
  std::string out = absl::StrFormat(
      "// Generated from NumericalDesign and Implementation; see "
      "circuit.textproto.\n"
      "module sfu_poly(input wire clk, reset, in_valid,\n"
      "  input wire [%d:0] row, input wire [%d:0] x,\n"
      "  output wire out_valid, output wire [%d:0] y);\n",
      address - 1, c.design().t().width() - 1, c.design().y().width() - 1);
  std::vector<const Gate*> inputs;
  for (const auto& g : c.gates())
    if (g.live() && g.operation() == Gate::INPUT &&
        (g.input_group() == "a" || g.input_group() == "b" ||
         g.input_group() == "c"))
      inputs.push_back(&g);
  if (!inputs.empty()) {
    absl::StrAppendFormat(&out,
                          "reg [%d:0] rom;\nalways @* begin\n  case (row)\n",
                          inputs.size() - 1);
    for (int r = 0; r < c.design().table_size(); ++r) {
      const auto& coeff = c.design().table(r);
      std::string bits;
      for (auto it = inputs.rbegin(); it != inputs.rend(); ++it) {
        const auto& g = **it;
        uint64_t word = g.input_group() == "a"   ? coeff.a()
                        : g.input_group() == "b" ? coeff.b()
                                                 : coeff.c();
        bits += ((word >> g.input_bit()) & 1) ? '1' : '0';
      }
      absl::StrAppendFormat(&out, "    %d'd%d: rom = %d'b%s;\n", address, r,
                            inputs.size(), bits);
    }
    absl::StrAppend(&out, "    default: rom = '0;\n  endcase\nend\n");
  } else {
    absl::StrAppend(&out, "wire unused_row = &{1'b0, row};\n");
  }
  int rom_index = 0;
  for (const auto& g : c.gates()) {
    if (!g.live() || g.id() < 2) continue;
    absl::StrAppendFormat(&out, "%s n%d;\n",
                          g.operation() == Gate::REGISTER ? "reg" : "wire",
                          g.id());
    if (g.operation() == Gate::REGISTER) continue;
    std::string rhs;
    if (g.operation() == Gate::INPUT) {
      if (g.input_group() == "valid")
        rhs = "in_valid";
      else if (g.input_group() == "x")
        rhs = absl::StrFormat("x[%d]", g.input_bit());
      else
        rhs = absl::StrFormat("rom[%d]", rom_index++);
    } else if (g.operation() == Gate::NOT)
      rhs = absl::StrCat("~", Ref(g.operands(0)));
    else {
      const char* op = g.operation() == Gate::XOR   ? "^"
                       : g.operation() == Gate::AND ? "&"
                                                    : "|";
      rhs = absl::StrCat(Ref(g.operands(0)), " ", op, " ", Ref(g.operands(1)));
    }
    absl::StrAppendFormat(&out, "assign n%d = %s;\n", g.id(), rhs);
  }
  absl::StrAppend(&out, "always @(posedge clk) begin\n");
  for (const auto& g : c.gates())
    if (g.live() && g.operation() == Gate::REGISTER)
      absl::StrAppendFormat(&out, "  n%d <= %s%s;\n", g.id(),
                            g.reset_zero() ? "reset ? 1'b0 : " : "",
                            Ref(g.operands(0)));
  absl::StrAppend(&out, "end\n");
  for (int j = 0; j < c.output_bits_size(); ++j)
    absl::StrAppendFormat(&out, "assign y[%d] = %s;\n", j,
                          Ref(c.output_bits(j)));
  absl::StrAppendFormat(&out, "assign out_valid = %s;\nendmodule\n",
                        Ref(c.output_valid()));
  return out;
}
std::string EmitDiagram(const Circuit& c) {
  std::array<int, 7> registers{}, gates{};
  for (const auto& g : c.gates())
    if (g.live() && g.stage() >= 0 && g.stage() <= 6) {
      if (g.operation() == Gate::REGISTER)
        ++registers[g.stage()];
      else if (g.operation() != Gate::INPUT)
        ++gates[g.stage()];
    }
  std::string out =
      "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 1120 660\" "
      "role=\"img\">\n"
      "<title>Generated polynomial pipeline</title><rect width=\"1120\" "
      "height=\"660\" fill=\"#faf9f5\"/>"
      "<g font-family=\"Arial,sans-serif\" fill=\"#353e42\">";
  absl::StrAppendFormat(
      &out, "<text x=\"32\" y=\"38\" font-size=\"23\">%s / %s</text>",
      Escape(absl::StrReplaceAll(c.design().name(), {{"_", " "}})),
      Escape(absl::StrReplaceAll(c.implementation().name(), {{"_", " "}})));
  const char* labels[] = {
      "ROM / decode",    "First bit heap",    "First completion",
      "Second bit heap", "Second completion", "Final narrowing",
      "Output"};
  const char* four_cycle_labels[] = {"Table lookup", "First multiply-add",
                                     "Second heap / carry", "Second completion",
                                     "Output"};
  for (int stage = 0; stage <= int(c.design().register_stages()); ++stage) {
    int x = 32 + stage * 154;
    absl::StrAppendFormat(
        &out,
        "<rect x=\"%d\" y=\"80\" width=\"138\" height=\"125\" rx=\"4\" "
        "fill=\"#ece9e0\" stroke=\"#97a0a2\"/>"
        "<text x=\"%d\" y=\"104\" font-size=\"15\">Stage %d</text><text "
        "x=\"%d\" y=\"132\" font-size=\"13\">%s</text>"
        "<text x=\"%d\" y=\"159\" font-size=\"13\">%d register "
        "bits</text><text x=\"%d\" y=\"184\" font-size=\"13\">%d Boolean "
        "gates</text>",
        x, x + 10, stage, x + 10,
        c.implementation().has_pipeline()
            ? "Scheduled stage"
            : (c.design().register_stages() == 4 ? four_cycle_labels[stage]
                                                 : labels[stage]),
        x + 10, registers[stage], x + 10, gates[stage]);
    if (stage < int(c.design().register_stages()))
      absl::StrAppendFormat(
          &out,
          "<path d=\"M%d 140h16\" stroke=\"#3d6f8c\" stroke-width=\"2\"/>",
          x + 138);
  }
  absl::StrAppend(
      &out,
      "<text x=\"32\" y=\"244\" font-size=\"16\">Product rows, correction rows "
      "and aligned coefficient; low weights at right</text>");
  for (int h = 0; h < c.heaps_size(); ++h) {
    const auto& heap = c.heaps(h);
    int base = 280 + h * 170;
    absl::StrAppendFormat(&out,
                          "<text x=\"32\" y=\"%d\" font-size=\"16\">%s</text>",
                          base, Escape(heap.name()));
    const double step = 940.0 / heap.width();
    const int retained_fraction =
        h == 0 ? c.design().s().fraction() : c.design().y().fraction();
    const int drop = int(heap.fraction()) - retained_fraction;
    if (drop > 0 && drop < int(heap.width())) {
      const double boundary = 150 + (heap.width() - drop) * step - 1;
      absl::StrAppendFormat(&out,
                            "<path d=\"M%.2f %dv%d\" stroke=\"#69767e\" "
                            "stroke-dasharray=\"3 3\"/>"
                            "<text x=\"%.2f\" y=\"%d\" "
                            "font-size=\"12\">Narrowing boundary</text>",
                            boundary, base - 20, heap.rows_size() * 10 + 18,
                            boundary - 65, base + heap.rows_size() * 10 + 15);
    }
    for (int r = 0; r < heap.rows_size(); ++r)
      for (int j = 0; j < heap.rows(r).bits_size(); ++j) {
        uint32_t id = heap.rows(r).bits(j);
        if (id == 0) continue;
        absl::StrAppendFormat(&out,
                              "<rect x=\"%.2f\" y=\"%d\" width=\"%.2f\" "
                              "height=\"7\" fill=\"%s\"/>",
                              150 + (heap.width() - 1 - j) * step,
                              base - 12 + r * 10, std::max(2.0, step - 2),
                              id == 1 ? "#bf6b35" : "#3d6f8c");
      }
  }
  absl::StrAppend(
      &out,
      "<text x=\"32\" y=\"620\" font-size=\"14\">Blue: variable "
      "bit. Rust: constant one. Counts include live gates only; "
      "constants do not need registers.</text><text x=\"32\" y=\"644\" "
      "font-size=\"13\">Boolean gate counts exclude ROM selection. Register "
      "counts include valid and carried operands.</text></g></svg>\n");
  return out;
}
std::string EmitFixture(const NumericalDesign& d) {
  std::string out =
      "#pragma once\n#include <array>\n#include <cstdint>\n#include "
      "\"sfu/fixed.h\"\nnamespace fixture {\n";
  absl::StrAppendFormat(
      &out, "inline constexpr int kRows=%d, kResidual=%d, kLatency=%d;\n",
      d.table_size(), d.t().width(), d.register_stages());
  for (auto [name, f] :
       std::vector<std::pair<const char*, WordFormat>>{{"A", d.a()},
                                                       {"B", d.b()},
                                                       {"C", d.c()},
                                                       {"T", d.t()},
                                                       {"S", d.s()},
                                                       {"Y", d.y()}})
    absl::StrAppendFormat(&out, "inline constexpr sfu::Format k%s{%d,%d};\n",
                          name, f.width(), f.fraction());
  absl::StrAppendFormat(
      &out,
      "inline constexpr sfu::Rounding kFirst=sfu::Rounding::%s, "
      "kSecond=sfu::Rounding::%s;\n",
      d.first_rounding() == RNE ? "kNearestEven" : "kTruncate",
      d.second_rounding() == RNE ? "kNearestEven" : "kTruncate");
  absl::StrAppendFormat(
      &out, "inline constexpr std::array<std::array<uint64_t,3>,%d> kTable{{\n",
      d.table_size());
  for (const auto& r : d.table())
    absl::StrAppendFormat(&out, "  {%u,%u,%u},\n", r.a(), r.b(), r.c());
  absl::StrAppend(&out, "}};\n}\n");
  return out;
}
std::string EmitBench() {
  return R"cpp(#include <cstdint>
#include <deque>
#include <iostream>
#include <random>
#include "fixture.h"
#include "Vsfu_poly.h"
#include "verilated.h"
#include "verilated_vcd_c.h"
#ifndef CLOCK_PERIOD_PS
#define CLOCK_PERIOD_PS 1000
#endif
               static_assert(CLOCK_PERIOD_PS > 0 && CLOCK_PERIOD_PS % 2 == 0);
               int main(int argc, char** argv) {
                 Verilated::commandArgs(argc, argv);
                 Verilated::traceEverOn(true);
                 Vsfu_poly dut;
                 VerilatedVcdC trace;
                 dut.trace(&trace, 99);
                 trace.open(argc > 1 ? argv[1] : "activity.vcd");
                 struct Result {
                   bool valid;
                   uint64_t value;
                 };
                 std::deque<Result> queue(fixture::kLatency - 1, {false, 0});
                 std::mt19937_64 random(0x535655);
                 uint64_t time = 0;
                 const uint64_t mask = (uint64_t(1) << fixture::kResidual) - 1;
                 for (int cycle = 0; cycle < 16392; ++cycle) {
                   dut.reset = cycle < 2 || cycle == 8192 || cycle == 8193;
                   dut.in_valid = cycle < 16384 && cycle % 7 != 0;
                   dut.row = cycle % fixture::kRows;
                   dut.x = cycle % 5 == 0 ? 0 : cycle % 5 == 1 ? mask : random() & mask;
                   const auto& r = fixture::kTable[dut.row];
                   sfu::Fixed x(dut.x, fixture::kT);
                   auto s = sfu::MultiplyAdd(sfu::Fixed(r[0], fixture::kA), x,
                                             sfu::Fixed(r[1], fixture::kB),
                                             fixture::kS, fixture::kFirst);
                   auto y =
                       sfu::MultiplyAdd(s, x, sfu::Fixed(r[2], fixture::kC),
                                        fixture::kY, fixture::kSecond);
                   dut.clk = 0;
                   dut.eval();
                   trace.dump(time);
                   time += CLOCK_PERIOD_PS / 2;
                   dut.clk = 1;
                   dut.eval();
                   trace.dump(time);
                   time += CLOCK_PERIOD_PS / 2;
                   if (dut.reset) {
                     queue.assign(fixture::kLatency - 1, {false, 0});
                     if (dut.out_valid || dut.y) return 1;
                   } else {
                     auto expected = queue.front();
                     queue.pop_front();
                     queue.push_back({bool(dut.in_valid), y.raw()});
                     if (bool(dut.out_valid) != expected.valid ||
                         (expected.valid && dut.y != expected.value)) {
                       std::cerr << "Mismatch at cycle " << cycle << ": "
                                 << dut.y << " vs " << expected.value << '\n';
                       return 1;
                     }
                   }
                 }
                 dut.final();
                 trace.close();
                 std::cout << "PASS: 16392 cycles, exact fixed-point model, "
                              "bubbles and repeated reset\n";
               }
  )cpp";
}
}  // namespace sfu::rtl
