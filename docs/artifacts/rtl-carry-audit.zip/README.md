# Why the bit-8 hybrid maps faster than full-width prefix

This audit compares the two four-cycle 800 ps implementations from the clock
study. Both use the same table, formats, truncations, Booth rows and column
compression. Measurements use ASAP7 RVT TT cell delays and pin capacitance,
with ideal clocks and no wire parasitics. There is no placement, congestion or
routing explanation for this result.

## The generator change

Full-width prefix scans both 36-bit compressed rows with group distances
1, 2, 4, 8, 16 and 32. The hybrid completes the low eight columns by ripple,
then scans the remaining 28 columns with distances 1, 2, 4, 8 and 16. Its low
carry is an input to the upper group summaries. Both produce the same retained
bits 20–34.

Columns 1–7 of the second compressed row are zero. Their ripple carry reduces
to AND operations. That describes a compact way to produce c8, but does not
explain the measured critical-path improvement: the worst path in both mapped
circuits starts at the registered coefficient a[3], passes through column 22,
and ends at s[14]. It does not follow the low-eight-bit ripple chain.

## The actual critical path

The synthesis recipe was replayed with named-net snapshots inserted before
wire hiding. The replayed circuits have identical cell types, pin connections
and output connectivity to the saved mapped circuits. Wire names differ;
normalized topology hashes and source/library/constraint hashes are recorded
in each replay's verification.json.

Named source functions were identified at mapped checkpoints, then checked
with combinational SAT miters. The miters cut at R1 and preserve equal and
complementary registered coefficient-bit relations from all 256 table rows.
They prove the source functions at the reported checkpoints, including P22,
c30 and the final sum bit; simulation signatures were only candidate matches.
The generator's carry construction identifies each source node's bit range.

P22 is the propagate bit of compressed column 22. The measured critical paths
have this breakdown, including launch clock-to-Q:

| Path segment | Full-width prefix (ps) | Bit-8 hybrid (ps) | Hybrid minus prefix (ps) |
|---|---:|---:|---:|
| Launch through P22 | 546.1209 | 554.0822 | +7.9613 |
| P22 through carry c30 | 156.0272 | 129.3069 | −26.7203 |
| c30 through result bit s[14] | 59.3236 | 50.0885 | −9.2351 |
| Data arrival | 761.4717 | 733.4776 | −27.9941 |

The hybrid starts this carry portion almost 8 ps behind. Its P22 output has
**four loads / 2.4874 fF**, compared with **two / 1.4128 fF** for full prefix.
Reduced fanout at this checkpoint is therefore not the reason it wins.

The carry regrouping gives ABC different Boolean factorizations. The mapped
P22-to-c30 paths use four cells each, but different gates and timing arcs:

| Full-width prefix | Cell delay (ps) | Bit-8 hybrid | Cell delay (ps) |
|---|---:|---|---:|
| AND2x2 | 29.0551 | NAND3xp33 | 26.7217 |
| OA211x2 | 34.4730 | AOI211xp5 | 21.2868 |
| O2A1O1Ixp33 | 34.1654 | NOR2xp33 | 27.4059 |
| NOR2xp33 | 58.3335 | O2A1O1Ixp33 | 53.8926 |

Cell delays include the measured input slew and output pin load. Above c30,
the prefix mapping uses NAND4 then XOR2; the hybrid uses NAND3 then XOR2,
with different signal polarities and corresponding arcs. That suffix saves
another 9.2351 ps. The endpoint setup requirement is slightly different,
leaving a **27.4050 ps slack improvement**: −1.6503 to +25.7547 ps.

Thus the observed benefit is in the **mapped upper carry path's cell choices,
factoring, loads and transition arcs**, not a faster low ripple chain or fewer
mapped cells along this particular path. The generator's prefix construction
is a uniform scan, not an arrival-aware optimum over all prefix structures.

## Control: prefix below eight and prefix above eight

A third circuit keeps prefix completion for the low eight columns, followed by
a prefix network above that boundary. This uses existing generator options:
`resolved_columns: 8`, both adders PREFIX, and no internal first-MAC register.
The numerical truncation remains at column 20.

| First-MAC construction | Area (µm²) | R1/R2/R3/R4 setup slack (ps) |
|---|---:|---|
| Full-width prefix | 298.01520 | 261.19 / −1.65 / 49.54 / 148.23 |
| Prefix below 8, prefix above 8 | 299.54610 | 297.80 / 8.02 / 69.87 / 178.78 |
| Ripple below 8, prefix above 8 | 299.56068 | 286.63 / 25.75 / 31.84 / 181.68 |

The prefix/prefix control also closes. Separating the low carry and regrouping
the upper scan can therefore help without using ripple. The hybrid retains
more timing margin in these mapped circuits. The control changes its global
worst endpoint, so differences in these worst slacks are complete-circuit
outcomes, not an additive timing attribution to the low adder alone.

The control passes the generator's exact-model checks, RTL simulation and
mapped-gate simulation. Its constraints and library hashes match the two
original measurements. No coefficient refit or numerical model change occurs.
The raw reports, generated inputs, RTL and compiled simulators are retained
in split8_prefix_results/; summary.json combines the measurements.

## Reproduction and evidence

Build and check the control in the existing hashed conda environment:

```sh
python3 scripts/bazel.py test -c opt \
  //rtl/producer/carry_audit:split8_prefix_test \
  //rtl/producer/carry_audit:split8_prefix_gate_test
bazel-bin/rtl/producer/audit_stages \
  --mapped=bazel-bin/rtl/producer/carry_audit/split8_prefix/mapped \
  --sdc=rtl/producer/carry_audit/clock_800.sdc \
  --output=/tmp/split8-prefix-audit --paths=3
```

The original pair's mapping replays and proofs are stored under:

- ../clock_search/results/t800_c4_unified_prefix/carry_audit/
- ../clock_search/results/t800_c4_unified_hybrid/carry_audit/

Each contains observe_mapping.ys, named graphs, cell-name correspondence,
verified_trace.json, source_carry_tags.json, carry_miter.sv, prove.ys and
proof.log. Replay those scripts using the pinned Yosys binary. The source
checkpoint list distinguishes proved functions from initial signature matches.
