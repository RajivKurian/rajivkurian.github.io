#ifndef RAJIV_BLOG_SFU_FIXED_H_
#define RAJIV_BLOG_SFU_FIXED_H_

#include <bit>
#include <cstdint>
#include <stdexcept>
#include <utility>

namespace sfu {

// A word's width describes physical storage. Its binary point describes what
// the stored integer *means*: value = raw * 2^-fraction. A negative integer
// width lets small coefficients use all their bits for precision: an 11-bit
// coefficient entirely below 2^-12 can carry 23 fractional bits. Functions
// can share physical widths while choosing binary points for their magnitudes.
struct Format {
  int width;
  int fraction;
};

// A full 63x63-bit product fits in this scratch word. Keeping those bits until
// an explicitly selected narrowing point separates exact alignment and
// accumulation from the precision retained for the next operation.
using Wide = unsigned __int128;

enum class Rounding { kNearestEven, kTruncate };

inline Wide RoundShift(Wide value, int shift) {
  if (shift <= 0) {
    if (-shift >= 128) throw std::overflow_error("fixed-point alignment");
    if (shift < 0 && (value >> (128 + shift)))
      throw std::overflow_error("fixed-point scratch overflow");
    return value << -shift;
  }
  if (shift >= 128) throw std::overflow_error("fixed-point alignment");
  const Wide retained = value >> shift;
  const Wide discarded = value - (retained << shift);
  const Wide half = Wide(1) << (shift - 1);
  // At a tie, the retained low bit decides which neighbor is even. The
  // caller chooses numerical narrowing points independently of register cuts.
  return retained +
         Wide(discarded > half || (discarded == half && (retained & 1)));
}

// Truncation of our unsigned words drops bits without an incrementer.
// Alignment toward a finer scale is exact for either narrowing rule.
inline Wide QuantizeShift(Wide value, int shift, Rounding rounding) {
  if (rounding == Rounding::kNearestEven || shift <= 0)
    return RoundShift(value, shift);
  if (shift >= 128) throw std::overflow_error("fixed-point alignment");
  return value >> shift;
}

// The inverse narrowing rule gives an interval of pre-narrow integers. RNE
// even
// endpoints own their midpoint ties; odd endpoints exclude those ties.
// Signed bounds let the cell around zero extend below zero before the caller
// intersects it with an unsigned coefficient or accumulator domain.
inline std::pair<__int128, __int128> RoundShiftPreimage(
    uint64_t lower, uint64_t upper, int shift,
    Rounding rounding = Rounding::kNearestEven) {
  if (lower > upper || shift < -126 || shift > 126 ||
      (shift > 0 && std::bit_width(upper) + shift > 126))
    throw std::invalid_argument("unsupported rounding interval");
  __int128 low = lower, high = upper;
  if (shift > 0 && rounding == Rounding::kTruncate) {
    low <<= shift;
    high = ((high + 1) << shift) - 1;
  } else if (shift > 0) {
    const __int128 half = __int128{1} << (shift - 1);
    low = (low << shift) - half + (lower & 1);
    high = (high << shift) + half - (upper & 1);
  } else if (shift < 0) {
    const __int128 step = __int128{1} << -shift;
    low = (low + step - 1) / step;
    high /= step;
  }
  return {low, high};
}

class Fixed {
 public:
  Fixed(uint64_t raw, Format format) : raw_(raw), format_(format) {
    if (format.width < 1 || format.width > 63 || format.fraction < 0 ||
        format.fraction > 63 || raw >= (uint64_t{1} << format.width)) {
      throw std::overflow_error(
          "fixed-point word does not fit its declared format");
    }
  }
  uint64_t raw() const { return raw_; }
  Format format() const { return format_; }

  static Fixed FromWide(Wide value, Format format) {
    if (format.width < 1 || format.width > 63 || (value >> format.width) != 0)
      throw std::overflow_error("fixed-point pipeline overflow");
    return Fixed(static_cast<uint64_t>(value), format);
  }

 private:
  uint64_t raw_;
  Format format_;
};

inline Fixed MultiplyAdd(Fixed a, Fixed x, Fixed b, Format destination,
                         Rounding rounding = Rounding::kNearestEven) {
  const int product_fraction = a.format().fraction + x.format().fraction;
  const int common_fraction = product_fraction > b.format().fraction
                                  ? product_fraction
                                  : b.format().fraction;
  if (common_fraction > 120)
    throw std::overflow_error("fixed-point scratch precision");
  // Keep the full product until the add is complete, then round once at the
  // stage boundary. This defines two fused fixed-point multiply-add stages,
  // rather than four independently rounded arithmetic operations.
  Wide product = Wide(a.raw()) * Wide(x.raw());
  product = RoundShift(product, product_fraction - common_fraction);
  const Wide addend =
      RoundShift(Wide(b.raw()), b.format().fraction - common_fraction);
  if (~Wide(0) - product < addend)
    throw std::overflow_error("fixed-point scratch overflow");
  return Fixed::FromWide(
      QuantizeShift(product + addend, common_fraction - destination.fraction,
                    rounding),
      destination);
}

// The search needs run-time formats. A selected architecture can instead use
// compile-time words: FixedWord<11, -12> has 11 physical bits and 23 fractional
// bits. No floating-point conversion is implicit; raw words come from the
// separately generated coefficient ROM. Both interfaces share the same exact
// arithmetic and overflow checks.
template <int Width, int IntegerBits>
class FixedWord {
 public:
  static_assert(Width > 0 && Width <= 63);
  static_assert(Width - IntegerBits >= 0 && Width - IntegerBits <= 63);
  static FixedWord FromRaw(uint64_t raw) {
    return FixedWord(Fixed(raw, {Width, Width - IntegerBits}));
  }
  uint64_t raw() const { return value_.raw(); }
  Fixed value() const { return value_; }

 private:
  explicit FixedWord(Fixed value) : value_(value) {}
  Fixed value_;
};

template <int OutputWidth, int OutputIntegerBits, int Aw, int Ai, int Xw,
          int Xi, int Bw, int Bi>
FixedWord<OutputWidth, OutputIntegerBits> MultiplyAdd(FixedWord<Aw, Ai> a,
                                                      FixedWord<Xw, Xi> x,
                                                      FixedWord<Bw, Bi> b) {
  const Fixed result =
      MultiplyAdd(a.value(), x.value(), b.value(),
                  {OutputWidth, OutputWidth - OutputIntegerBits});
  return FixedWord<OutputWidth, OutputIntegerBits>::FromRaw(result.raw());
}

}  // namespace sfu

#endif  // RAJIV_BLOG_SFU_FIXED_H_
