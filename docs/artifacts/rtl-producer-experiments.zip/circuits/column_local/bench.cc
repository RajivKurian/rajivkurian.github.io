#include <cstdint>
#include <deque>
#include <iostream>
#include <random>
#include "fixture.h"
#include "Vsfu_poly.h"
#include "verilated.h"
#include "verilated_vcd_c.h"
               int main(int argc, char** argv) {
                 Verilated::commandArgs(argc, argv);
                 Verilated::traceEverOn(true);
                 Vsfu_poly dut;
                 VerilatedVcdC trace;
                 dut.trace(&trace, 99);
                 trace.open(argc > 1 ? argv[1] : "activity.vcd");
                 struct Result {
                   bool valid;
                   uint64_t value;
                 };
                 std::deque<Result> queue(fixture::kLatency - 1, {false, 0});
                 std::mt19937_64 random(0x535655);
                 uint64_t time = 0;
                 const uint64_t mask = (uint64_t(1) << fixture::kResidual) - 1;
                 for (int cycle = 0; cycle < 16392; ++cycle) {
                   dut.reset = cycle < 2 || cycle == 8192 || cycle == 8193;
                   dut.in_valid = cycle < 16384 && cycle % 7 != 0;
                   dut.row = cycle % fixture::kRows;
                   dut.x = cycle % 5 == 0 ? 0 : cycle % 5 == 1 ? mask : random() & mask;
                   const auto& r = fixture::kTable[dut.row];
                   sfu::Fixed x(dut.x, fixture::kT);
                   auto s = sfu::MultiplyAdd(sfu::Fixed(r[0], fixture::kA), x,
                                             sfu::Fixed(r[1], fixture::kB),
                                             fixture::kS, fixture::kFirst);
                   auto y =
                       sfu::MultiplyAdd(s, x, sfu::Fixed(r[2], fixture::kC),
                                        fixture::kY, fixture::kSecond);
                   dut.clk = 0;
                   dut.eval();
                   trace.dump(time);
                   time += 500;
                   dut.clk = 1;
                   dut.eval();
                   trace.dump(time);
                   time += 500;
                   if (dut.reset) {
                     queue.assign(fixture::kLatency - 1, {false, 0});
                     if (dut.out_valid || dut.y) return 1;
                   } else {
                     auto expected = queue.front();
                     queue.pop_front();
                     queue.push_back({bool(dut.in_valid), y.raw()});
                     if (bool(dut.out_valid) != expected.valid ||
                         (expected.valid && dut.y != expected.value)) {
                       std::cerr << "Mismatch at cycle " << cycle << ": "
                                 << dut.y << " vs " << expected.value << '\n';
                       return 1;
                     }
                   }
                 }
                 dut.final();
                 trace.close();
                 std::cout << "PASS: 16392 cycles, exact fixed-point model, "
                              "bubbles and repeated reset\n";
               }
  