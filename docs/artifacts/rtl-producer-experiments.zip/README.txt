Part 4: recorded polynomial implementation experiments

producer/: C++ producer, protobuf schemas, implementation configurations.
circuits/: generated/reference RTL, exact-model benches, mapped netlists,
           diagrams, circuit protobufs and checked simulation logs.
measurements/: mapped area, timing and activity-based power with source hashes.
experiment.textproto: the numerical design and all implementation choices.

Build in the code/ workspace using producer/README.md. The producer's Bazel
rules use the code workspace's pinned source dependencies and published EDA
bundle. Compile one sfu_poly top at a time when inspecting the circuit folders.
The measurements cover coefficient lookup and polynomial arithmetic at 1 ns,
ASAP7 RVT TT, with four register stages and one input per cycle.
