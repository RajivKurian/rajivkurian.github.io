"""Generate RTL, its exact-model bench and diagrams from the same circuit IR."""
load("//rtl:rules.bzl", "rtl_design", "rtl_test")

def _produce_impl(ctx):
    names = ["sfu_poly.sv", "fixture.h", "bench.cc", "circuit.textproto", "circuit.pb", "pipeline.svg"]
    outputs = {name: ctx.actions.declare_file(ctx.label.name + "/" + name) for name in names}
    args = ctx.actions.args()
    args.add("--design", ctx.file.design)
    args.add("--implementation", ctx.file.implementation)
    args.add("--output", outputs["sfu_poly.sv"].dirname)
    ctx.actions.run(
        executable = ctx.executable._generator,
        inputs = [ctx.file.design, ctx.file.implementation],
        outputs = outputs.values(),
        arguments = [args],
        mnemonic = "ProducePolynomialRtl",
    )
    return [DefaultInfo(files = depset(outputs.values())), OutputGroupInfo(
        rtl = depset([outputs["sfu_poly.sv"]]),
        bench = depset([outputs["bench.cc"]]),
        headers = depset([outputs["fixture.h"]]),
        diagram = depset([outputs["pipeline.svg"]]),
        circuit = depset([outputs["circuit.textproto"], outputs["circuit.pb"]]),
    )]

produce = rule(implementation = _produce_impl, attrs = {
    "design": attr.label(allow_single_file = [".textproto"], mandatory = True),
    "implementation": attr.label(allow_single_file = [".textproto"], mandatory = True),
    "_generator": attr.label(default = "//rtl/producer:generate", executable = True, cfg = "exec"),
})

def polynomial_experiment(name, design = "fixtures/exp2.textproto", implementation = None):
    produce(name = name + "_generated", design = design, implementation = implementation or "fixtures/" + name + ".textproto")
    for group in ["rtl", "bench", "headers"]:
        native.filegroup(name = name + "_" + group, srcs = [":" + name + "_generated"], output_group = group)
    rtl_design(name = name, top = "sfu_poly", srcs = [":" + name + "_rtl"],
        bench = ":" + name + "_bench", bench_hdrs = [":" + name + "_headers", "//sfu:fixed.h"],
        liberty = ["//rtl/technology:asap7_rvt_tt"], sdc = "//rtl/producer:polynomial.sdc")
    native.filegroup(name = name + "_sim", srcs = [":" + name], output_group = "simulator")
    native.filegroup(name = name + "_gate", srcs = [":" + name], output_group = "mapped_simulator")
    rtl_test(name = name + "_test", simulator = ":" + name + "_sim")
    rtl_test(name = name + "_gate_test", simulator = ":" + name + "_gate")
