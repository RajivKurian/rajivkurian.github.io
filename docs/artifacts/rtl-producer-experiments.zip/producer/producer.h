#ifndef RAJIV_BLOG_RTL_PRODUCER_PRODUCER_H_
#define RAJIV_BLOG_RTL_PRODUCER_PRODUCER_H_

#include <cstdint>
#include <string>
#include <vector>

#include "absl/status/status.h"
#include "absl/status/statusor.h"
#include "absl/strings/string_view.h"
#include "rtl/producer/schema.pb.h"

namespace sfu::rtl {
absl::Status Validate(const NumericalDesign& design,
                      const Implementation& implementation);
absl::StatusOr<Circuit> Lower(const NumericalDesign& design,
                              const Implementation& implementation);
std::string EmitSystemVerilog(const Circuit& circuit);
std::string EmitDiagram(const Circuit& circuit);
std::string EmitFixture(const NumericalDesign& design);
std::string EmitBench();

// The graph interpreter and emitted RTL consume the same graph. Its expected
// answer comes independently from fixed.h's full-width integer multiply-add.
class Simulator {
 public:
  explicit Simulator(const Circuit& circuit);
  struct Output {
    bool valid;
    uint64_t value;
  };
  Output Tick(uint32_t row, uint64_t residual, bool valid, bool reset);

 private:
  const Circuit& circuit_;
  std::vector<bool> registers_;
  std::vector<bool> values_;
  void Evaluate(uint32_t row, uint64_t residual, bool valid);
};
absl::Status Verify(const Circuit& circuit, int cycles);
}  // namespace sfu::rtl
#endif
