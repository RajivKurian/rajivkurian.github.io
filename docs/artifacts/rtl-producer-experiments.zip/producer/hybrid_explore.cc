#include <spawn.h>
#include <sys/wait.h>
#include <unistd.h>

#include <algorithm>
#include <chrono>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <iterator>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>

#include "absl/container/flat_hash_map.h"
#include "absl/flags/flag.h"
#include "absl/flags/parse.h"
#include "absl/strings/str_cat.h"
#include "absl/strings/str_format.h"
#include "google/protobuf/struct.pb.h"
#include "google/protobuf/text_format.h"
#include "google/protobuf/util/json_util.h"
#include "rtl/producer/producer.h"

ABSL_FLAG(std::string, phase, "prepare", "prepare, execute or collect");
ABSL_FLAG(std::string, batch, "carry", "carry, cuts, latency or checkpoints");
ABSL_FLAG(std::string, parent, "",
          "Saved candidate to use as the sweep parent");
ABSL_FLAG(int, jobs, 2, "Concurrent Bazel EDA actions");
ABSL_FLAG(int, chunk_size, 6, "Bound the number of temporary waveform sets");
extern char** environ;
namespace {
namespace fs = std::filesystem;
using namespace sfu::rtl;
using google::protobuf::Struct;
const fs::path kRoot = "rtl/producer/hybrid_search";
std::string Read(const fs::path& p) {
  std::ifstream f(p);
  if (!f) throw std::runtime_error("cannot read " + p.string());
  return {(std::istreambuf_iterator<char>(f)), {}};
}
void Write(const fs::path& p, const std::string& value) {
  fs::create_directories(p.parent_path());
  std::ofstream f(p);
  f << value;
  if (!f) throw std::runtime_error("cannot write " + p.string());
}
template <class T>
T Proto(const fs::path& p) {
  T value;
  if (!google::protobuf::TextFormat::ParseFromString(Read(p), &value))
    throw std::runtime_error("invalid proto " + p.string());
  return value;
}
template <class T>
void Save(const fs::path& p, const T& value) {
  std::string text;
  google::protobuf::TextFormat::PrintToString(value, &text);
  Write(p, text);
}
Struct Json(const fs::path& p) {
  Struct value;
  if (!google::protobuf::util::JsonStringToMessage(Read(p), &value).ok())
    throw std::runtime_error("invalid JSON " + p.string());
  return value;
}
const google::protobuf::Value& Field(const Struct& s, const std::string& name) {
  return s.fields().at(name);
}
std::string JsonText(const Struct& value) {
  std::string text;
  google::protobuf::util::JsonPrintOptions options;
  options.add_whitespace = true;
  if (!google::protobuf::util::MessageToJsonString(value, &text, options).ok())
    throw std::runtime_error("JSON encoding failed");
  return text;
}
struct Candidate {
  NumericalDesign d;
  Implementation i;
  std::string why;
};
AdderPlan Adder(const std::string& name) {
  AdderPlan p;
  if (name == "r")
    p.set_kind(RIPPLE);
  else if (name == "p")
    p.set_kind(PREFIX);
  else if (name[0] == 'h') {
    p.set_kind(HYBRID);
    p.set_ripple_bits(std::stoi(name.substr(1)));
  } else {
    p.set_kind(BLOCK_LOOKAHEAD);
    p.set_block_bits(std::stoi(name.substr(1)));
  }
  return p;
}
std::vector<Candidate> Candidates() {
  Candidate base;
  base.d =
      Proto<NumericalDesign>("rtl/producer/fixtures/exp2-six-cycle.textproto");
  base.i =
      Proto<Implementation>("rtl/producer/fixtures/column_local.textproto");
  const auto parent = absl::GetFlag(FLAGS_parent);
  if (!parent.empty()) {
    base.d = Proto<NumericalDesign>(kRoot / (parent + ".design.textproto"));
    base.i = Proto<Implementation>(kRoot / (parent + ".impl.textproto"));
  }
  std::vector<Candidate> out;
  const auto batch = absl::GetFlag(FLAGS_batch);
  auto add = [&](Candidate c, const std::string& name, const std::string& why) {
    c.i.set_name(parent.empty() ? name : parent + "__" + name);
    c.why = why;
    out.push_back(std::move(c));
  };
  add(base, "baseline", "Rerun the parent under the current flow.");
  const std::vector<std::string> styles = {"r",   "p",  "h2", "h4", "h8",
                                           "h12", "b2", "b4", "b8"};
  if (batch == "carry") {
    for (const auto& style : styles) {
      Candidate c = base;
      for (auto* mac : {c.i.mutable_first_mac(), c.i.mutable_second_mac()}) {
        *mac->mutable_low_adder() = Adder(style);
        *mac->mutable_high_adder() = Adder(style);
      }
      add(c, "carry_all_" + style,
          "Compare a uniform carry topology before isolating its location.");
      if (style == "r") continue;
      for (int place = 0; place < 4; ++place) {
        c = base;
        auto* mac =
            place < 2 ? c.i.mutable_first_mac() : c.i.mutable_second_mac();
        *(place % 2 == 0 ? mac->mutable_low_adder()
                         : mac->mutable_high_adder()) = Adder(style);
        add(c, absl::StrFormat("carry_%d_%s", place, style),
            "Change only one low/upper adder; preserve the other three.");
      }
    }
    for (const auto& low : {"r", "h4", "b4"})
      for (const auto& high : {"r", "h4", "b4"}) {
        Candidate c = base;
        for (auto* mac : {c.i.mutable_first_mac(), c.i.mutable_second_mac()}) {
          *mac->mutable_low_adder() = Adder(low);
          *mac->mutable_high_adder() = Adder(high);
        }
        add(c, absl::StrCat("carry_pair_", low, "_", high),
            "Use different carry organizations on the two sides of each cut.");
      }
  } else if (batch == "cuts") {
    for (int stage = 0; stage < 2; ++stage)
      for (int k : {0, 8, 12, 15, 17, 18, 20, 21, 22, 24, 28, 32, 36, 42}) {
        if (stage == 0 && k > 36) continue;
        Candidate c = base;
        auto* mac =
            stage == 0 ? c.i.mutable_first_mac() : c.i.mutable_second_mac();
        mac->clear_prefix_levels_before_cut();
        mac->set_resolved_columns(k);
        mac->set_compression_layers_before_cut(0);
        add(c, absl::StrFormat("cut_%d_k%d", stage, k),
            "Move the exact low-column boundary independently of numerical "
            "narrowing.");
      }
    for (int k1 : {16, 20, 24, 28})
      for (int k2 : {13, 17, 21, 25}) {
        Candidate c = base;
        c.i.mutable_first_mac()->set_resolved_columns(k1);
        c.i.mutable_second_mac()->set_resolved_columns(k2);
        add(c, absl::StrFormat("cut_pair_%d_%d", k1, k2),
            "Combine asymmetric resolved-column boundaries.");
      }
    for (int stage = 0; stage < 2; ++stage)
      for (int layers : {1, 2, 3}) {
        Candidate c = base;
        auto* mac =
            stage == 0 ? c.i.mutable_first_mac() : c.i.mutable_second_mac();
        mac->clear_prefix_levels_before_cut();
        mac->set_resolved_columns(0);
        mac->set_compression_layers_before_cut(layers);
        add(c, absl::StrFormat("cut_%d_layer%d", stage, layers),
            "Cut one compressor independently; the other MAC keeps its parent "
            "cut.");
      }
  } else if (batch == "checkpoints") {
    for (int stage = 0; stage < 3; ++stage)
      for (int levels = 0; levels <= 6; ++levels) {
        Candidate c = base;
        for (int index = 0; index < 2; ++index) {
          if (stage != 2 && stage != index) continue;
          auto* mac =
              index == 0 ? c.i.mutable_first_mac() : c.i.mutable_second_mac();
          mac->clear_resolved_columns();
          mac->set_compression_layers_before_cut(0);
          mac->set_prefix_levels_before_cut(levels);
        }
        add(c, absl::StrFormat("prefix_cut_%d_l%d", stage, levels),
            "Register partially completed prefix summaries instead of "
            "carry-save rows.");
      }
  } else if (batch == "latency") {
    for (int latency : {6, 5, 4, 3})
      for (int operand : {1, 0})
        for (int first_result : {1, 2, 3}) {
          if (first_result >= latency || first_result <= operand) continue;
          for (int first_cut : {operand, first_result - 1}) {
            Candidate c = base;
            c.d.set_register_stages(latency);
            auto* p = c.i.mutable_pipeline();
            p->set_operand_stage(operand);
            p->set_first_cut_stage(first_cut);
            p->set_first_result_stage(first_result);
            p->set_second_cut_stage(latency - 1);
            add(c,
                absl::StrFormat("lat%d_i%d_c%d_s%d", latency, operand,
                                first_cut, first_result),
                "Retain both numerical narrowings while moving or removing "
                "registers.");
          }
        }
  } else
    throw std::runtime_error("unknown batch " + batch);
  return out;
}
void Prepare() {
  Struct manifest;
  auto* list = (*manifest.mutable_fields())["candidates"].mutable_list_value();
  absl::flat_hash_map<std::string, std::string> seen;
  std::string names;
  for (const auto& c : Candidates()) {
    auto circuit = Lower(c.d, c.i);
    if (!circuit.ok())
      throw std::runtime_error(c.i.name() + ": " + circuit.status().ToString());
    const auto status = Verify(*circuit, 512);
    if (!status.ok())
      throw std::runtime_error(c.i.name() + ": " + status.ToString());
    auto* row = list->add_values()->mutable_struct_value();
    auto& f = *row->mutable_fields();
    f["name"].set_string_value(c.i.name());
    f["hypothesis"].set_string_value(c.why);
    f["latency"].set_number_value(c.d.register_stages());
    const std::string rtl = EmitSystemVerilog(*circuit);
    const auto found = seen.find(rtl);
    if (found != seen.end()) {
      f["same_emitted_rtl_as"].set_string_value(found->second);
      continue;
    }
    seen[rtl] = c.i.name();
    int regs = 0;
    std::vector<int> depths(circuit->gates_size());
    std::vector<int> stage_depths(7);
    for (const auto& g : circuit->gates()) {
      if (!g.live()) continue;
      if (g.operation() == Gate::REGISTER)
        ++regs;
      else if (g.operation() != Gate::INPUT && g.id() > 1) {
        for (auto arg : g.operands())
          depths[g.id()] = std::max(depths[g.id()], depths[arg]);
        ++depths[g.id()];
        stage_depths[g.stage()] =
            std::max(stage_depths[g.stage()], depths[g.id()]);
      }
    }
    f["graph_register_bits"].set_number_value(regs);
    auto* depths_list = f["boolean_depth_by_stage"].mutable_list_value();
    for (int depth : stage_depths)
      depths_list->add_values()->set_number_value(depth);
    Save(kRoot / (c.i.name() + ".impl.textproto"), c.i);
    Save(kRoot / (c.i.name() + ".design.textproto"), c.d);
    absl::StrAppend(&names, c.i.name(), "\n");
  }
  std::string build =
      "load(\"//rtl/producer:generate.bzl\", \"polynomial_experiment\")\n\n";
  std::vector<std::string> all;
  for (const auto& entry : fs::directory_iterator(kRoot)) {
    auto name = entry.path().filename().string();
    const std::string suffix = ".impl.textproto";
    if (name.size() > suffix.size() &&
        name.substr(name.size() - suffix.size()) == suffix)
      all.push_back(name.substr(0, name.size() - suffix.size()));
  }
  std::sort(all.begin(), all.end());
  for (const auto& name : all)
    absl::StrAppendFormat(
        &build,
        "polynomial_experiment(name=\"%s\", design=\"%s.design.textproto\", "
        "implementation=\"%s.impl.textproto\")\n",
        name, name, name);
  Write(kRoot / "BUILD.bazel", build);
  const std::string key =
      absl::GetFlag(FLAGS_parent) + "_" + absl::GetFlag(FLAGS_batch);
  Write(kRoot / "plans" / (key + ".json"), JsonText(manifest));
  Write(kRoot / "plans" / (key + ".txt"), names);
  std::cout << "Verified " << list->values_size() << " proposals; "
            << seen.size() << " distinct emitted circuits.\n";
}
std::vector<std::string> Names() {
  const std::string key =
      absl::GetFlag(FLAGS_parent) + "_" + absl::GetFlag(FLAGS_batch);
  std::istringstream text(Read(kRoot / "plans" / (key + ".txt")));
  std::vector<std::string> names;
  for (std::string line; std::getline(text, line);)
    if (!line.empty()) names.push_back(line);
  return names;
}
int Build(const std::vector<std::string>& names) {
  std::vector<std::string> args = {
      "python3",     "scripts/bazel.py",
      "build",       "-c",
      "opt",         absl::StrCat("--jobs=", absl::GetFlag(FLAGS_jobs)),
      "--keep_going"};
  for (const auto& name : names)
    args.push_back("//rtl/producer/hybrid_search:" + name);
  std::vector<char*> argv;
  for (auto& arg : args) argv.push_back(arg.data());
  argv.push_back(nullptr);
  pid_t pid;
  int status =
      posix_spawnp(&pid, argv[0], nullptr, nullptr, argv.data(), environ);
  if (status) return status;
  if (waitpid(pid, &status, 0) < 0) return 1;
  return WIFEXITED(status) ? WEXITSTATUS(status) : 1;
}
std::string Context() {
  std::string value;
  for (const auto* path :
       {"rtl/flow.py", "rtl/rules.bzl", "rtl/toolchain.lock.json",
        "rtl/producer/polynomial.sdc", "rtl/technology/BUILD.bazel",
        "MODULE.bazel"})
    absl::StrAppend(&value, path, "\n", Read(path), "\n");
  return value;
}
fs::path CachedPath(const std::string& name) {
  return kRoot / "results/completed" / name;
}
bool CacheReady(const std::string& name) {
  const auto cache = CachedPath(name);
  if (!fs::exists(cache / "context.txt") ||
      Read(cache / "context.txt") != Context())
    return false;
  const auto d = Proto<NumericalDesign>(kRoot / (name + ".design.textproto"));
  const auto i = Proto<Implementation>(kRoot / (name + ".impl.textproto"));
  auto circuit = Lower(d, i);
  return circuit.ok() &&
         Read(cache / "generated/sfu_poly.sv") == EmitSystemVerilog(*circuit) &&
         Read(cache / "generated/bench.cc") == EmitBench() &&
         Read(cache / "generated/fixture.h") == EmitFixture(d);
}
bool CacheCompleted(const std::string& name) {
  const auto path = fs::path("bazel-bin/rtl/producer/hybrid_search") / name;
  if (!fs::exists(path / "reports/summary.json")) return false;
  const auto generated = fs::path(path.string() + "_generated");
  const auto d = Proto<NumericalDesign>(kRoot / (name + ".design.textproto"));
  const auto i = Proto<Implementation>(kRoot / (name + ".impl.textproto"));
  const auto saved = Proto<Circuit>(generated / "circuit.textproto");
  auto expected = Lower(d, i);
  if (!expected.ok() ||
      saved.design().SerializeAsString() != d.SerializeAsString() ||
      saved.implementation().SerializeAsString() != i.SerializeAsString() ||
      Read(generated / "sfu_poly.sv") != EmitSystemVerilog(*expected) ||
      Read(generated / "fixture.h") != EmitFixture(d) ||
      Read(generated / "bench.cc") != EmitBench())
    return false;
  for (const auto* filename : {"simulation.log", "gate_simulation.log"})
    if (Read(path / filename).find("PASS:") == std::string::npos) return false;
  const auto report = Json(path / "reports/summary.json");
  const auto cache = CachedPath(name);
  const auto staging = fs::path(cache.string() + ".pending");
  fs::remove_all(staging);
  fs::create_directories(staging / "generated");
  fs::create_directories(staging / "mapped");
  fs::create_directories(staging / "reports");
  for (const auto* filename :
       {"sfu_poly.sv", "fixture.h", "bench.cc", "pipeline.svg", "circuit.pb",
        "circuit.textproto"})
    fs::copy_file(generated / filename, staging / "generated" / filename);
  for (const auto* filename :
       {"simulation.log", "gate_simulation.log", "lint.log"})
    fs::copy_file(path / filename, staging / filename);
  for (const auto* filename : {"netlist.v", "statistics.json"})
    fs::copy_file(path / "mapped" / filename, staging / "mapped" / filename);
  for (const auto* filename : {"summary.json", "timing_power.log"})
    fs::copy_file(path / "reports" / filename, staging / "reports" / filename);
  const auto library =
      kRoot / "results/libraries" /
      (Field(report, "library_sha256").string_value() + ".lib");
  fs::create_directories(library.parent_path());
  if (!fs::exists(library)) fs::copy_file(path / "mapped/asap7.lib", library);
  fs::create_hard_link(library, staging / "mapped/asap7.lib");
  Write(staging / "context.txt", Context());
  fs::remove_all(cache);
  fs::rename(staging, cache);
  return true;
}
void PruneTraces(const std::string& name) {
  // Power, its VCD hash and both simulation logs have been saved. The binaries
  // and input stream regenerate traces; retain the compact reports, not raw
  // VCD.
  const auto path = fs::path("bazel-bin/rtl/producer/hybrid_search") / name;
  for (const auto* filename : {"rtl.vcd", "gate.vcd"})
    fs::remove(path / filename);
}
void Collect() {
  const auto stamp = std::chrono::duration_cast<std::chrono::microseconds>(
                         std::chrono::system_clock::now().time_since_epoch())
                         .count();
  const auto output = kRoot / "results/runs" / absl::StrCat(stamp);
  fs::create_directories(output);
  Struct result;
  auto* list = (*result.mutable_fields())["measurements"].mutable_list_value();
  std::string table =
      "| Circuit | Cycles | Area (µm²) | Slack (ps) | Power (mW) | FFs "
      "|\n|---|---:|---:|---:|---:|---:|\n";
  std::string identity;
  for (const auto& name : Names()) {
    const auto path =
        CacheReady(name)
            ? CachedPath(name)
            : fs::path("bazel-bin/rtl/producer/hybrid_search") / name;
    auto* row = list->add_values()->mutable_struct_value();
    (*row->mutable_fields())["name"].set_string_value(name);
    if (!fs::exists(path / "reports/summary.json")) {
      (*row->mutable_fields())["status"].set_string_value("not built");
      continue;
    }
    auto report = Json(path / "reports/summary.json");
    const auto d = Proto<NumericalDesign>(kRoot / (name + ".design.textproto"));
    const auto i = Proto<Implementation>(kRoot / (name + ".impl.textproto"));
    const auto generated = CacheReady(name)
                               ? path / "generated"
                               : fs::path(path.string() + "_generated");
    const auto circuit = Proto<Circuit>(generated / "circuit.textproto");
    if (circuit.design().SerializeAsString() != d.SerializeAsString() ||
        circuit.implementation().SerializeAsString() != i.SerializeAsString())
      throw std::runtime_error("stale result " + name);
    const auto fingerprint =
        absl::StrCat(Field(report, "eda_bundle_id").string_value(),
                     Field(report, "library_sha256").string_value(),
                     Field(report, "sdc_sha256").string_value());
    if (!identity.empty() && fingerprint != identity)
      throw std::runtime_error("inconsistent EDA inputs");
    identity = fingerprint;
    for (const auto* log : {"simulation.log", "gate_simulation.log"})
      if (Read(path / log).find("PASS:") == std::string::npos)
        throw std::runtime_error("unchecked RTL " + name);
    auto stat = Json(path / "mapped/statistics.json");
    const auto& cells =
        Field(Field(stat, "design").struct_value(), "num_cells_by_type")
            .struct_value();
    int ff = 0;
    for (const auto& e : cells.fields())
      if (e.first.find("DFF") != std::string::npos)
        ff += e.second.number_value();
    const double area = Field(report, "cell_area_um2").number_value();
    const double slack = Field(report, "worst_setup_slack_ps").number_value();
    const double power =
        Field(Field(Field(report, "power").struct_value(), "Total")
                  .struct_value(),
              "total")
            .number_value() *
        1000;
    auto& f = *row->mutable_fields();
    f["area_um2"].set_number_value(area);
    f["slack_ps"].set_number_value(slack);
    f["power_mw"].set_number_value(power);
    f["flip_flops"].set_number_value(ff);
    f["latency"].set_number_value(d.register_stages());
    f["status"].set_string_value(slack >= 0 ? "passes" : "timing failure");
    *f["report"].mutable_struct_value() = report;
    absl::StrAppendFormat(&table, "| %s | %d | %.3f | %.2f | %.4f | %d |\n",
                          name, d.register_stages(), area, slack, power, ff);
    const auto artifact = output / name;
    fs::create_directories(artifact);
    for (const auto* filename :
         {"sfu_poly.sv", "fixture.h", "bench.cc", "pipeline.svg", "circuit.pb",
          "circuit.textproto"})
      fs::copy_file(generated / filename, artifact / filename);
    for (const auto* filename :
         {"simulation.log", "gate_simulation.log", "lint.log"})
      fs::copy_file(path / filename, artifact / filename);
    fs::copy_file(path / "mapped/netlist.v", artifact / "netlist.v");
    fs::copy_file(path / "mapped/statistics.json",
                  artifact / "statistics.json");
    fs::copy_file(path / "reports/timing_power.log",
                  artifact / "timing_power.log");
  }
  Write(output / "results.json", JsonText(result));
  Write(output / "comparison.md", table);
  // Preserve the generator that produced each collection alongside its outputs.
  for (const auto* filename : {"schema.proto", "producer.cc", "emit.cc",
                               "producer.h", "hybrid_explore.cc"})
    Write(output / "producer" / filename,
          Read(fs::path("rtl/producer") / filename));
  const std::string key =
      absl::GetFlag(FLAGS_parent) + "_" + absl::GetFlag(FLAGS_batch);
  Write(output / "plan.json", Read(kRoot / "plans" / (key + ".json")));
  Write(kRoot / "results" / (key + ".json"), JsonText(result));
  Write(kRoot / "results" / (key + ".md"), table);
  std::cout << table << "Archived in " << output << '\n';
}
}  // namespace
int main(int argc, char** argv) {
  absl::ParseCommandLine(argc, argv);
  try {
    const auto phase = absl::GetFlag(FLAGS_phase);
    if (phase == "prepare")
      Prepare();
    else if (phase == "collect")
      Collect();
    else if (phase == "cache") {
      for (const auto& name : Names())
        if (CacheCompleted(name)) PruneTraces(name);
    } else if (phase == "execute") {
      std::vector<std::string> pending;
      for (const auto& name : Names())
        if (!CacheReady(name)) pending.push_back(name);
      const int chunk = std::max(1, absl::GetFlag(FLAGS_chunk_size));
      int status = 0;
      for (size_t start = 0; start < pending.size(); start += chunk) {
        const std::vector<std::string> group(
            pending.begin() + start,
            pending.begin() + std::min(pending.size(), start + chunk));
        status = Build(group);
        for (const auto& name : group)
          if (CacheCompleted(name)) PruneTraces(name);
        if (status) break;
      }
      Collect();
      return status;
    } else
      throw std::runtime_error("invalid phase");
  } catch (const std::exception& e) {
    std::cerr << e.what() << '\n';
    return 1;
  }
}
