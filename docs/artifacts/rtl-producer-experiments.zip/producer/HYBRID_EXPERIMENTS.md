# Hybrid carry and register-cut exploration

The numerical fixture is the same exhaustively accepted 256-row exp2 fit used
in the first producer study: coefficient formats 8/24, 13/20 and 23/22,
residual 18/18, retained results 15/22 and 25/23, with two truncations.
The following experiments change how that integer computation is implemented.

## Questions and parameters

At the 1 ns target, the main opportunities are removing register stages and
reducing the number of bits crossing the remaining cuts. Carry topology is
most useful when it makes those schedules meet timing. We measure carry-only
changes separately, then use them to repair the limiting paths of smaller
pipelines. Area, power and latency determine the main frontier after timing
passes; extra timing margin is recorded separately for a possible faster clock.

The old experiment selected one carry style for every addition and placed both
cuts at their numerical narrowing boundaries. That couples four distinct
adders with different operands and arrival times. The new `MacPlan` gives each
multiply-add its own low and upper adder and its own cut representation.

### Carry networks

- **Ripple:** propagate carry one bit at a time.
- **Prefix:** combine bit generate/propagate signals over doubling spans.
- **Hybrid:** ripple through a selected number of low bits, then complete the
  upper portion with a prefix network. The split is relative to the particular
  low or upper word being added, not to the original FP32 mantissa.
- **Block lookahead:** generate block carry summaries, prefix across blocks,
  then ripple within each block. This changes local depth, fanout and duplicated
  carry logic differently from putting a single prefix suffix after a ripple.

The first sweep tries uniform profiles, changes each of the four adders alone,
and combines different profiles before and after the cuts. Ripple spans are
2/4/8/12 bits; lookahead blocks are 2/4/8 bits. Full ripple and full prefix are
included. Each profile receives the same fitted coefficient table.

### What the cut stores

A resolved-column cut completes the low `k` columns before the register. It
stores their carry and any completed result bits still needed afterward,
alongside the uncompleted upper pair. `k` is independent of the numerical
narrowing position. The first numerical boundary discards 20 aligned bits;
the second discards 17. Trying `k` on both sides of those boundaries changes
which retained bits have already been added, not which numerical bits survive.

An earlier compression cut instead stores the remaining heap after one, two
or three layers. Each multiply-add can choose its own layer count.

A prefix checkpoint stores partial generate/propagate summaries and original
XOR bits after a selected number of prefix levels. Remaining levels resume
after the register. Reachability removes summaries and discarded sum bits
that do not influence the result. This representation can store more signals
than a carry-save pair, but can distribute the carry work differently.

### Clock-cycle schedules

`PipelinePlan` separately chooses the operand-capture, first-compression cut,
first narrowed-result and second-compression-cut stages. An operand stage of
zero combines table lookup and arithmetic before the first register. Three,
four, five and six output stages are supported. The two narrowing rules and
formats are unchanged. Throughput stays one input per cycle.

## Procedure and retained evidence

`hybrid_explore.cc` prepares the directed sweeps. It constructs each circuit,
checks it against the independent integer model, and records its register
count and per-stage Boolean depth. Identical emitted RTL is recorded as an
alias rather than measured twice within a batch. These counts describe the
circuits; synthesis determines their mapped comparisons.

The generated Bazel package is `hybrid_search/`. Each target runs generator
verification, Verilator lint and RTL simulation, Yosys/ABC mapping, mapped-gate
simulation and OpenSTA timing/activity-power analysis. The tool bundle,
ASAP7 RVT TT library, 1 ns constraint and input stimulus are shared. Timing
failures remain in the results. A lower-latency candidate is compared as a
separate latency choice rather than silently mixed into a fixed-latency table.

The expanded unit test exhausts every coefficient row and residual in the
small fixture across RNE/truncation, hybrid spans, block widths, arbitrary
resolved-column cuts and prefix checkpoints. It also checks stage schedules
from three through six cycles, including bubbles and reset flushing. Real
circuits undergo the independent integer-model stream and both RTL and mapped
simulation. This tests preservation of the fitted arithmetic; no coefficient
refitting is involved in these experiments.

Each collection in `hybrid_search/results/runs/` retains the complete input
specifications in `circuit.textproto`, generated RTL and fixture, mapped netlist,
cell inventory, checked simulation logs, critical path, original report hashes,
the proposal manifest and the generator sources. Top-level batch JSON and
Markdown files summarize the latest completed collection for that batch.

## Running the sweeps

From `code/` in its content-addressed conda environment:

```sh
python3 scripts/bazel.py test //rtl/producer:producer_test -c opt
python3 scripts/bazel.py build //rtl/producer:hybrid_explore -c opt
bazel-bin/rtl/producer/hybrid_explore --phase=prepare --batch=carry
bazel-bin/rtl/producer/hybrid_explore --phase=execute --batch=carry
```

Repeat preparation/execution for `cuts`, `checkpoints` and `latency`. A follow-up
can use `--parent=CANDIDATE` to sweep around a saved implementation. This keeps
combined changes and their parent explicit rather than reusing a result from a
different circuit. EDA binaries come from the existing pinned release; these
experiments do not compile Yosys/ABC/OpenSTA.

## Measurements

The original six-stage baseline was reproduced byte-for-byte in RTL and gate
activity, with identical area, timing, power and testbench hashes. Its stage audit
shows slack of 419.73 / 307.54 / 528.52 / 249.23 / 331.04 / 800.75 ps into
register-depth groups 1 through 6. The second compression/low-carry stage limits
the clock, while the last stage mostly forwards a retained result. This motivates
independent carry choices and removing the final forwarding stage.

The first broad carry sweep initially accumulated 7.35 GiB of completed raw
traces before hitting a disk-space limit. Completed reports, netlists and checks
were retained. The runner now measures six circuits per chunk, saves each to
`results/completed/`, and removes the reproducible raw traces only after saving
their power reports and hashes. The production mapping/analysis flow is unchanged;
EDA tools and compiled simulators are retained. The bounded-storage run reuses
completed measurements and continues the unmeasured candidates.

The broad sweeps were stopped in favor of stage-path analysis and targeted
schedule changes. The simple four-cycle schedule passed without changing the
arithmetic structures and is now the default. Its results and stage paths are
in [FOUR_CYCLES.md](FOUR_CYCLES.md). Completed sweep measurements remain archived;
the unmeasured proposals are not results.
