#include "rtl/producer/producer.h"

#include <cassert>
#include <deque>
#include <fstream>
#include <iostream>
#include <iterator>
#include <string>

#include "google/protobuf/text_format.h"
#include "sfu/fixed.h"

namespace {
using namespace sfu::rtl;
NumericalDesign Small() {
  NumericalDesign d;
  d.set_schema_version(1);
  d.set_name("small");
  d.set_register_stages(6);
  auto format = [](WordFormat* f, int w, int fraction) {
    f->set_width(w);
    f->set_fraction(fraction);
  };
  format(d.mutable_a(), 3, 6);
  format(d.mutable_b(), 4, 5);
  format(d.mutable_c(), 6, 5);
  format(d.mutable_t(), 4, 4);
  format(d.mutable_s(), 7, 6);
  format(d.mutable_y(), 9, 6);
  for (int a = 0; a < 8; ++a)
    for (int b = 0; b < 16; ++b) {
      auto* row = d.add_table();
      row->set_a(a);
      row->set_b(b);
      row->set_c((a * 7 + b * 3) % 64);
    }
  d.set_first_rounding(RNE);
  d.set_second_rounding(RNE);
  return d;
}
void Check(const NumericalDesign& d, const Implementation& i, int cycles) {
  auto circuit = Lower(d, i);
  if (!circuit.ok()) {
    std::cerr << circuit.status() << '\n';
    std::abort();
  }
  auto status = Verify(*circuit, cycles);
  if (!status.ok()) {
    std::cerr << i.DebugString() << status << '\n';
    std::abort();
  }
  if (d.name() == "small") {
    // Every coefficient row and every residual, including ties, goes through
    // the configured pipeline. This catches arithmetic errors separately
    // from the randomized bubbles/reset exercise above.
    Simulator simulator(*circuit);
    std::deque<Simulator::Output> expected(d.register_stages() - 1, {false, 0});
    simulator.Tick(0, 0, false, true);
    auto format = [](const WordFormat& f) {
      return sfu::Format{int(f.width()), int(f.fraction())};
    };
    auto mode = [](Narrowing n) {
      return n == RNE ? sfu::Rounding::kNearestEven : sfu::Rounding::kTruncate;
    };
    for (int j = 0; j < d.table_size() * 16 + int(d.register_stages()); ++j) {
      bool valid = j < d.table_size() * 16;
      int row = (j / 16) % d.table_size(), t = j % 16;
      const auto& r = d.table(row);
      sfu::Fixed x(t, format(d.t()));
      auto first = sfu::MultiplyAdd(sfu::Fixed(r.a(), format(d.a())), x,
                                    sfu::Fixed(r.b(), format(d.b())),
                                    format(d.s()), mode(d.first_rounding()));
      auto final = sfu::MultiplyAdd(first, x, sfu::Fixed(r.c(), format(d.c())),
                                    format(d.y()), mode(d.second_rounding()));
      auto actual = simulator.Tick(row, t, valid, false);
      auto next = expected.front();
      expected.pop_front();
      expected.push_back({valid, final.raw()});
      assert(actual.valid == next.valid);
      assert(!next.valid || actual.value == next.value);
    }
  }
  assert(EmitSystemVerilog(*circuit).find("module sfu_poly") !=
         std::string::npos);
  assert(EmitDiagram(*circuit).find("<svg") != std::string::npos);
}
}  // namespace
int main() {
  auto small = Small();
  Implementation i;
  i.set_schema_version(1);
  i.set_name("test");
  i.set_recoding(NARROW_OPERAND);
  i.set_decode_storage(LOCAL);
  i.set_compression(ROW_TREE);
  i.set_carry_adder(RIPPLE);
  for (auto first : {RNE, TRUNCATE})
    for (auto second : {RNE, TRUNCATE}) {
      small.set_first_rounding(first);
      small.set_second_rounding(second);
      for (auto recoding : {NARROW_OPERAND, RESIDUAL})
        for (auto storage : {LOCAL, CARRIED}) {
          if (storage == CARRIED && recoding != RESIDUAL) continue;
          i.set_recoding(recoding);
          i.set_decode_storage(storage);
          for (auto compression : {ROW_TREE, COLUMN_GREEDY})
            for (auto carry : {RIPPLE, PREFIX}) {
              i.set_compression(compression);
              i.set_carry_adder(carry);
              for (bool low : {false, true}) {
                i.set_resolve_low_columns(low);
                Check(small, i, 1024);
              }
            }
        }
    }
  i.set_resolve_low_columns(false);
  i.set_compression_layers_before_cut(1);
  Check(small, i, 2048);
  i.set_resolve_low_columns(true);
  assert(!Validate(small, i).ok());
  i.set_compression_layers_before_cut(0);
  std::ifstream input("rtl/producer/fixtures/exp2.textproto");
  std::string text((std::istreambuf_iterator<char>(input)), {});
  NumericalDesign real;
  assert(google::protobuf::TextFormat::ParseFromString(text, &real));
  for (auto recoding : {NARROW_OPERAND, RESIDUAL}) {
    i.set_recoding(recoding);
    i.set_decode_storage(recoding == RESIDUAL ? CARRIED : LOCAL);
    Check(real, i, 4096);
  }
  std::ifstream implementation("rtl/producer/fixtures/column_local.textproto");
  std::string implementation_text(
      (std::istreambuf_iterator<char>(implementation)), {});
  Implementation selected;
  assert(google::protobuf::TextFormat::ParseFromString(implementation_text,
                                                       &selected));
  assert(real.register_stages() == 4);
  Check(real, selected, 16384);
  // The default must reproduce the measured four-cycle schedule, including
  // combining the complete first multiply-add between operand and s registers.
  auto default_circuit = Lower(real, selected);
  auto* schedule = selected.mutable_pipeline();
  schedule->set_operand_stage(1);
  schedule->set_first_cut_stage(1);
  schedule->set_first_result_stage(2);
  schedule->set_second_cut_stage(3);
  auto explicit_circuit = Lower(real, selected);
  assert(default_circuit.ok() && explicit_circuit.ok());
  assert(EmitSystemVerilog(*default_circuit) ==
         EmitSystemVerilog(*explicit_circuit));
  // Keep the coefficient/residual enumeration independent of the circuit.
  // Both narrowing modes exercise halfway carries across arbitrary cut columns.
  i.Clear();
  i.set_schema_version(1);
  i.set_name("hybrid_test");
  i.set_recoding(NARROW_OPERAND);
  i.set_decode_storage(LOCAL);
  i.set_compression(COLUMN_GREEDY);
  i.set_carry_adder(RIPPLE);
  i.set_resolve_low_columns(true);
  for (auto first : {RNE, TRUNCATE})
    for (auto second : {RNE, TRUNCATE}) {
      small.set_first_rounding(first);
      small.set_second_rounding(second);
      for (int span : {0, 1, 3, 7, 64}) {
        for (auto* mac : {i.mutable_first_mac(), i.mutable_second_mac()}) {
          mac->mutable_low_adder()->set_kind(HYBRID);
          mac->mutable_low_adder()->set_ripple_bits(span);
          mac->mutable_high_adder()->set_kind(HYBRID);
          mac->mutable_high_adder()->set_ripple_bits(span / 2);
        }
        Check(small, i, 512);
      }
      for (int block : {2, 3, 4, 8}) {
        for (auto* mac : {i.mutable_first_mac(), i.mutable_second_mac()}) {
          mac->mutable_low_adder()->set_kind(BLOCK_LOOKAHEAD);
          mac->mutable_low_adder()->set_block_bits(block);
          mac->mutable_high_adder()->set_kind(BLOCK_LOOKAHEAD);
          mac->mutable_high_adder()->set_block_bits(block);
        }
        Check(small, i, 512);
      }
      for (int columns : {0, 1, 3, 4, 7, 14}) {
        i.mutable_first_mac()->set_resolved_columns(columns);
        i.mutable_second_mac()->set_resolved_columns(columns / 2);
        Check(small, i, 512);
      }
      i.clear_first_mac();
      i.clear_second_mac();
      for (int levels : {0, 1, 2, 3, 8}) {
        i.mutable_first_mac()->set_prefix_levels_before_cut(levels);
        i.mutable_second_mac()->set_prefix_levels_before_cut(levels / 2);
        Check(small, i, 512);
      }
      i.clear_first_mac();
      i.clear_second_mac();
    }
  small.set_register_stages(4);
  for (auto first : {RNE, TRUNCATE})
    for (auto second : {RNE, TRUNCATE}) {
      small.set_first_rounding(first);
      small.set_second_rounding(second);
      Check(small, i, 512);
    }
  for (int latency : {3, 4, 5, 6}) {
    small.set_register_stages(latency);
    for (int operand : {0, 1})
      for (int first_result = operand + 1; first_result < latency;
           ++first_result) {
        auto* p = i.mutable_pipeline();
        p->set_operand_stage(operand);
        p->set_first_cut_stage(first_result - 1);
        p->set_first_result_stage(first_result);
        p->set_second_cut_stage(latency - 1);
        Check(small, i, 512);
      }
  }
  i.mutable_first_mac()->mutable_low_adder()->set_kind(BLOCK_LOOKAHEAD);
  assert(!Validate(small, i).ok());
  std::cout << "PASS: modes, operand orientations, shared decode, compressors, "
               "hybrid/group carry, prefix checkpoints, arbitrary columns, "
               "latency 3–6 and real table\n";
}
