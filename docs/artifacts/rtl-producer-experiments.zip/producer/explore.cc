#include <spawn.h>
#include <sys/wait.h>
#include <unistd.h>

#include <chrono>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <iterator>
#include <string>
#include <vector>

#include "absl/flags/flag.h"
#include "absl/flags/parse.h"
#include "absl/strings/str_cat.h"
#include "absl/strings/str_format.h"
#include "google/protobuf/struct.pb.h"
#include "google/protobuf/text_format.h"
#include "google/protobuf/util/json_util.h"
#include "rtl/producer/schema.pb.h"

ABSL_FLAG(std::string, workspace, ".",
          "code/ workspace containing scripts/bazel.py");
ABSL_FLAG(bool, execute, true,
          "Build, simulate, map and measure all variants before collecting");
ABSL_FLAG(std::string, results, "rtl/producer/results",
          "Persistent experiment directory");
extern char** environ;
namespace {
std::string Read(const std::filesystem::path& path) {
  std::ifstream file(path);
  if (!file) throw std::runtime_error("cannot read " + path.string());
  return std::string((std::istreambuf_iterator<char>(file)), {});
}
template <class T>
T Proto(const std::filesystem::path& path) {
  T message;
  if (!google::protobuf::TextFormat::ParseFromString(Read(path), &message))
    throw std::runtime_error("cannot parse " + path.string());
  return message;
}
google::protobuf::Struct Json(const std::filesystem::path& path) {
  google::protobuf::Struct message;
  auto status =
      google::protobuf::util::JsonStringToMessage(Read(path), &message);
  if (!status.ok()) throw std::runtime_error(std::string(status.message()));
  return message;
}
const google::protobuf::Value& Field(const google::protobuf::Struct& s,
                                     const std::string& key) {
  auto it = s.fields().find(key);
  if (it == s.fields().end())
    throw std::runtime_error("missing report field " + key);
  return it->second;
}
int Build(const std::vector<std::string>& names) {
  // argv is passed directly. Experiment names never become shell program text.
  std::vector<std::string> args = {"python3", "scripts/bazel.py", "build", "-c",
                                   "opt",     "--jobs=2"};
  for (const auto& name : names)
    args.push_back(absl::StrCat("//rtl/producer:", name));
  std::vector<char*> argv;
  for (auto& arg : args) argv.push_back(arg.data());
  argv.push_back(nullptr);
  pid_t pid;
  int status =
      posix_spawnp(&pid, argv[0], nullptr, nullptr, argv.data(), environ);
  if (status) return status;
  if (waitpid(pid, &status, 0) < 0) return 1;
  return WIFEXITED(status) ? WEXITSTATUS(status) : 1;
}
}  // namespace
int main(int argc, char** argv) {
  absl::ParseCommandLine(argc, argv);
  try {
    std::filesystem::current_path(absl::GetFlag(FLAGS_workspace));
    const std::vector<std::string> names = {
        "narrow_local", "residual_local",        "residual_carried",
        "column_local", "prefix_local",          "whole_rows",
        "early_cut",    "column_residual_local", "column_residual_carried",
        "column_prefix"};
    if (absl::GetFlag(FLAGS_execute)) {
      int status = Build(names);
      if (status) return status;
    }
    sfu::rtl::Experiment experiment;
    experiment.set_schema_version(1);
    *experiment.mutable_design() = Proto<sfu::rtl::NumericalDesign>(
        "rtl/producer/fixtures/exp2.textproto");
    const std::filesystem::path root(absl::GetFlag(FLAGS_results));
    const auto stamp = std::chrono::duration_cast<std::chrono::microseconds>(
                           std::chrono::system_clock::now().time_since_epoch())
                           .count();
    const std::filesystem::path output = root / "runs" / absl::StrCat(stamp);
    std::filesystem::create_directories(output);
    std::string table =
        "| Implementation | Area (µm²) | Slack (ps) | Activity power (mW) | "
        "FFs |\n| --- | ---: | ---: | ---: | ---: |\n";
    for (const auto& name : names) {
      auto path = std::filesystem::path("bazel-bin/rtl/producer") / name;
      auto summary = Json(path / "reports/summary.json");
      auto mapped = Json(path / "mapped/statistics.json");
      const std::string generated = name == "reference" ? "narrow_local" : name;
      auto circuit =
          Proto<sfu::rtl::Circuit>(std::string("bazel-bin/rtl/producer/") +
                                   generated + "_generated/circuit.textproto");
      auto expected = Proto<sfu::rtl::Implementation>("rtl/producer/fixtures/" +
                                                      generated + ".textproto");
      if (circuit.design().SerializeAsString() !=
              experiment.design().SerializeAsString() ||
          circuit.implementation().SerializeAsString() !=
              expected.SerializeAsString())
        throw std::runtime_error("stale generated design: " + name +
                                 "; rerun with --execute");
      if (name == "reference") expected.set_name("reference");
      *experiment.add_implementations() = expected;
      auto* m = experiment.add_measurements();
      m->set_implementation(name);
      m->set_mapped_area_um2(Field(summary, "cell_area_um2").number_value());
      m->set_setup_slack_ps(
          Field(summary, "worst_setup_slack_ps").number_value());
      const auto& power = Field(summary, "power").struct_value();
      m->set_activity_power_mw(
          Field(Field(power, "Total").struct_value(), "total").number_value() *
          1000);
      m->set_meets_setup_target(
          Field(summary, "meets_setup_target").bool_value());
      for (const auto& g : circuit.gates())
        if (name != "reference" && g.live() &&
            g.operation() == sfu::rtl::Gate::REGISTER)
          m->set_live_register_bits(m->live_register_bits() + 1);
      // Yosys stat reports cell types under design, after mapping and
      // flattening.
      const auto& cells =
          Field(Field(mapped, "design").struct_value(), "num_cells_by_type")
              .struct_value();
      for (const auto& entry : cells.fields())
        if (entry.first.find("DFF") != std::string::npos)
          m->set_mapped_flip_flops(m->mapped_flip_flops() +
                                   entry.second.number_value());
      m->set_report_json(name + ".json");
      m->set_rtl_sha256(
          Field(Field(summary, "rtl_sha256").struct_value(), "sfu_poly.sv")
              .string_value());
      const auto bundle = Field(summary, "eda_bundle_id").string_value();
      const auto library = Field(summary, "library_sha256").string_value();
      const auto sdc = Field(summary, "sdc_sha256").string_value();
      const double clock = Field(summary, "clock_period_ps").number_value();
      if (experiment.measurements_size() > 1 &&
          (experiment.eda_bundle_id() != bundle ||
           experiment.library_sha256() != library ||
           experiment.sdc_sha256() != sdc ||
           experiment.clock_period_ps() != clock))
        throw std::runtime_error("inconsistent comparison constraints");
      experiment.set_eda_bundle_id(bundle);
      experiment.set_library_sha256(library);
      experiment.set_sdc_sha256(sdc);
      experiment.set_clock_period_ps(clock);
      std::filesystem::copy_file(
          path / "reports/summary.json", output / (name + ".json"),
          std::filesystem::copy_options::overwrite_existing);
      const auto artifact = output / name;
      std::filesystem::create_directory(artifact);
      std::filesystem::copy_file(path / "mapped/statistics.json",
                                 artifact / "statistics.json");
      std::filesystem::copy_file(path / "mapped/netlist.v",
                                 artifact / "netlist.v");
      std::filesystem::copy_file(path / "reports/timing_power.log",
                                 artifact / "timing_power.log");
      std::filesystem::copy_file(path / "simulation.log",
                                 artifact / "simulation.log");
      std::filesystem::copy_file(path / "gate_simulation.log",
                                 artifact / "gate_simulation.log");
      const auto generated_path =
          std::filesystem::path("bazel-bin/rtl/producer") /
          (generated + "_generated");
      for (const auto& filename : {"fixture.h", "bench.cc"})
        std::filesystem::copy_file(generated_path / filename,
                                   artifact / filename);
      if (name != "reference") {
        for (const auto& filename :
             {"sfu_poly.sv", "pipeline.svg", "circuit.pb"})
          std::filesystem::copy_file(generated_path / filename,
                                     artifact / filename);
      } else {
        std::filesystem::copy_file("rtl/rounding/narrow256_s15_tt/sfu_poly.sv",
                                   artifact / "sfu_poly.sv");
        for (const auto& filename :
             {"rounding_polynomial.sv", "polynomial_reduce.sv"})
          std::filesystem::copy_file(
              std::filesystem::path("rtl/rounding") / filename,
              artifact / filename);
        for (const auto& filename : {"booth_rows.sv", "carry_save_layer.sv"})
          std::filesystem::copy_file(
              std::filesystem::path("rtl/examples") / filename,
              artifact / filename);
      }
      absl::StrAppendFormat(&table, "| %s | %.3f | %.2f | %.4f | %d |\n", name,
                            m->mapped_area_um2(), m->setup_slack_ps(),
                            m->activity_power_mw(), m->mapped_flip_flops());
    }
    std::string text;
    google::protobuf::TextFormat::PrintToString(experiment, &text);
    std::ofstream(output / "experiment.textproto") << text;
    std::ofstream(output / "comparison.md") << table;
    // Only publish the latest view once the complete comparison is collected.
    // Earlier runs retain their specs, generated sources and measured reports.
    for (const auto& entry :
         std::filesystem::recursive_directory_iterator(output)) {
      if (entry.is_regular_file())
        std::filesystem::permissions(entry.path(),
                                     std::filesystem::perms::owner_read |
                                         std::filesystem::perms::owner_write |
                                         std::filesystem::perms::group_read |
                                         std::filesystem::perms::others_read);
    }
    for (const auto& entry : std::filesystem::directory_iterator(output)) {
      if (!entry.is_regular_file()) continue;
      // Bazel outputs can be read-only. Rename a fresh copy over the old view
      // instead of trying to overwrite a copied read-only report in place.
      const auto temporary =
          root / absl::StrCat(".latest-", stamp, "-",
                              entry.path().filename().string());
      std::filesystem::copy_file(entry.path(), temporary);
      std::filesystem::rename(temporary, root / entry.path().filename());
    }
    std::cout << table << "Archived in " << output << '\n';
  } catch (const std::exception& e) {
    std::cerr << e.what() << '\n';
    return 1;
  }
}
