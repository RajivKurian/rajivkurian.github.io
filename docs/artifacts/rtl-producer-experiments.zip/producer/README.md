# C++ polynomial RTL producer

This takes a fitted polynomial design and explores how to implement its exact
integer arithmetic. The coefficients, binary points and narrowing rules remain
fixed while Booth recoding, compression, carry completion and register cuts vary.
The initial fixture is the 256-row exp2 quadratic with 8/13/23-bit coefficients,
an 18-bit residual, a 15-bit first result, a 25-bit final result and two
truncations. It is copied from the existing exhaustively checked fit.
The default pipeline returns a result after four cycles and accepts one input
per cycle. [Four-cycle implementation](FOUR_CYCLES.md) records its schedule,
stage timing and measured comparison.

## Inputs and outputs

[`schema.proto`](schema.proto) separates two inputs:

- `NumericalDesign` supplies coefficient words, formats, rounding rules and
  latency. [`fixtures/exp2.textproto`](fixtures/exp2.textproto) includes the
  SHA-256 of the source fit.
- `Implementation` supplies recoded operand, decoder placement, compressor
  organization, carry adder and compression cut. Experiment configurations live
  beside the numerical fixture.

The C++ lowerer builds a staged Boolean graph. A bit identifies its transaction
stage; combining bits from different stages fails instead of accidentally using
an operand from another input. Constant coefficient columns become constants
before any delay is inserted, so they propagate into both storage and arithmetic.
Shared expressions and register delays are reused. Only gates reachable from
output data or valid are emitted.

From this graph the generator writes:

- `sfu_poly.sv`: synthesizable four-stage RTL, one input per cycle.
- `circuit.pb` and `circuit.textproto`: the circuit and both complete input specs.
- `pipeline.svg`: stage counts and the two original bit heaps.
- `fixture.h` and `bench.cc`: a scoreboard using the separate full-width integer
  multiply-add model, with bubbles, endpoint residuals and repeated resets.

A graph interpreter checks arithmetic and latency before generation succeeds.
The generated RTL then runs through lint, RTL simulation, Yosys/ABC mapping,
gate simulation and OpenSTA using the existing pinned EDA release. The producer
and its dependencies build from source through Bazel; changing an experiment
never recompiles the EDA tools.

## Implementation choices

`narrow_local` recodes the narrower operand at each multiply: `a` first, then `s`.
`residual_local` recodes `t` twice. `residual_carried` decodes `t` once before
its first register and carries the one/two/negative controls to both multipliers.
Sharing decode trades combinational logic for more registered control bits.

The `column_residual_local`, `column_residual_carried` and `column_prefix`
variants combine those choices with column compression.

`column_local` packs and compresses columns independently instead of grouping
whole rows three at a time. `prefix_local` replaces ripple carry completion with
parallel-prefix completion. `whole_rows` retains the full compressed pair at
the cut; `narrow_local` instead resolves discarded columns into carry and rounding
information before storage. `early_cut` registers the heap after one compression
layer and finishes compression afterward. All current variants use four
register stages and the same numerical narrowing points. Only the second
multiply-add has an internal register cut; the first completes between R1 and R2.

The Booth generator keeps sign bias and negative-digit corrections as separate
addends. They may occupy the same columns when the recoded operand is wider
than the multiplicand. Treating these as disjoint bit fields loses carries.

## Build and run

From `code/`, activate the content-addressed conda environment as described in
the workspace README. Use the wrapper for every Bazel command:

```sh
python3 scripts/bazel.py test //rtl/producer:producer_test -c opt
python3 scripts/bazel.py build //rtl/producer:generate //rtl/producer:explore -c opt
bazel-bin/rtl/producer/explore --execute --workspace="$PWD"
```

The C++ experiment runner invokes Bazel with an argument vector and collects
measurements only after the actions finish. Bazel caches each generated circuit
and its flow outputs independently. Rerunning the same experiment reuses them.
Run the built runner directly so it can invoke Bazel itself.

For one configuration:

```sh
python3 scripts/bazel.py build //rtl/producer:residual_carried -c opt
```

For generation without EDA:

```sh
bazel-bin/rtl/producer/generate \
  --design=rtl/producer/fixtures/exp2.textproto \
  --implementation=rtl/producer/fixtures/residual_carried.textproto \
  --output=/tmp/exp2-residual-carried
```

Results are retained in `results/`: original measurement JSON with RTL, library,
tool and stimulus hashes; a typed `experiment.textproto`; and `comparison.md`.
The collector checks that all results use the same technology, clock and SDC,
and that generated specs match the current input fixtures. Every completed
collection is archived under `results/runs/` with the RTL, mapped netlists,
circuit protobufs, diagrams and verification logs; the files directly in
`results/` show the latest completed comparison.

## Verification and measurement scope

The unit tests exhaust every residual and coefficient row of a small arithmetic
fixture across both narrowing modes, recoding orientations, decode sharing,
compressor organizations and carry adders. They also exercise the real exp2
fixture and invalid specifications. Each generated real circuit has an additional
integer-model check followed by 16,392-cycle RTL and mapped-gate checks.
These check preservation of an existing numerical design; its exhaustive FP32
accuracy report belongs to the coefficient fit.

Measurements are mapped cell area, cell/pin-load timing and activity-based power
at the common 1 ns target in ASAP7 RVT TT. Placement and routing are a separate
measurement stage. The initial comparison and follow-up experiments are recorded
in [the experiment log](EXPERIMENTS.md).

## Hybrid carry and independent-cut study

The extended choices and retained measurements are documented in
[HYBRID_EXPERIMENTS.md](HYBRID_EXPERIMENTS.md). `first_mac` and `second_mac`
can override the low/upper adder, resolved-column boundary, compression depth,
or a cut inside the prefix network. `pipeline` selects transaction stages;
`NumericalDesign.register_stages` specifies the output latency. A four-cycle
design defaults to operand capture at R1, the complete first result at R2,
the second compression cut at R3, and output at R4. Six-cycle specifications
retain their original schedule; `fixtures/exp2-six-cycle.textproto` supports
replaying the archived study. The handwritten `reference` target has its own
six-cycle scoreboard and is separate from the current comparison.

`hybrid_explore` prepares directed sweeps, verifies their graphs, emits a Bazel
experiment package and collects checked mapped results. It runs bounded chunks,
saves a persistent result cache and removes raw waveforms after their power
reports and hashes are saved. Generator/tool/context and exact emitted RTL are
checked before reusing a cached measurement. Simulators remain available to
regenerate activity. `summarize_hybrids` reports non-dominated area/power/timing
alternatives within each latency and across latencies, without a weighted score.

`audit_stages` reads a mapped netlist in a separate Yosys process and groups
register endpoints by sequential depth. It asks OpenSTA for the worst path into
each group. This reveals which side of a cut limits timing without changing the
production synthesis run.
