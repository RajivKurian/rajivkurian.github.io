# Four-cycle polynomial pipeline

The default fixture and generated implementation targets now use four cycles.
The numerical design remains the accepted 256-row fit: 8/13/23-bit coefficients,
18-bit residual, 15-bit first result, 25-bit output, and two truncations.
`column_local` retains local narrow-operand Booth recoding, column compression
and ripple carry completion.

## Register placement

| Cycle | Work before the register | What the register holds |
|---|---|---|
| 1 | Coefficient lookup | Variable coefficient bits, residual and valid |
| 2 | Complete first multiply-add and its truncation | `s`, delayed `t` and `c`, valid |
| 3 | Second product generation, compression and low-column carry | Upper compressed pair, low carry and valid |
| 4 | Upper carry completion and final truncation | Output and valid |

The first MAC's former internal register and the final forwarding register are
removed. Numerical narrowing still happens after each complete multiply-add.
The result interval, coefficient words and arithmetic structures did not change.
One input is accepted per cycle, including consecutive transactions.

## Stage timing

The current mapped default was audited independently in OpenSTA. All paths use
the common 1 ns clock, 20 ps uncertainty, input/output constraints and ASAP7 RVT
TT library. The endpoint groups come from mapped sequential connectivity.

| Register | Mapped FFs | Worst path | Setup slack (ps) |
|---|---:|---|---:|
| R1 | 62 | Table address to coefficient capture | 442.26 |
| R2 | 56 | Captured `a[3]` through the complete first MAC to `s[14]` | 89.37 |
| R3 | 34 | `s[5]` through second-product compression and low-column addition | 207.52 |
| R4 | 26 | Second upper-sum completion to output | 286.75 |

The first MAC is now the limiting stage. Four cycles needed no hybrid carry
network: the original ripple implementation met timing after removing the two
banks. Further schedule changes should start from these paths and operand
arrivals. The full paths are in
[the stage audit](results/four-cycle-stage-audit/stage_paths.log).

## Measurements

| Column/local implementation | Cycles | Area (µm²) | Setup slack (ps) | Activity power (mW) | FFs |
|---|---:|---:|---:|---:|---:|
| Original schedule | 6 | 323.51562 | 249.23 | 0.9902101010 | 265 |
| Current default | 4 | 296.46972 | 89.37 | 0.8459346136 | 178 |

Removing the banks saves 87 mapped flip-flops, 8.36% of mapped area and 14.57%
of activity-based power. The timing margin decreases because the first MAC now
completes in one cycle. These measurements cover coefficient lookup and the
polynomial, with mapped cells and pin loads.

All ten existing generated implementation choices were rerun at four cycles.
Their full comparison and frozen specs, RTL, netlists, test logs and measurement
hashes are retained in
[run 1792716325267155](results/runs/1792716325267155/comparison.md).
The top-level `results/` files expose that current comparison. Original
six-cycle measurements remain in their archived runs.

The column/prefix variant measured 296.39682 µm², 218.35 ps slack and
0.8463889826 mW with the same 178 FFs. Its area/power are close to the ripple
default, while it offers more timing margin. We keep the ripple circuit as the
default starting point and retain both results.

## Verification and reproduction

All ten circuits passed generator/model checks, lint, RTL simulation and
mapped-gate simulation, and all met the clock target. The unit tests also cover
the four-cycle default under all four internal rounding-mode combinations,
exhausting the small fixture's coefficient/residual combinations. The real
default is checked with bubbles and repeated resets. A regression compares its
emitted RTL with the explicitly specified, previously measured four-cycle plan.

From `code/` in the pinned environment:

```sh
python3 scripts/bazel.py test //rtl/producer:producer_test \
  //rtl/producer:column_local_test //rtl/producer:column_local_gate_test -c opt
python3 scripts/bazel.py build //rtl/producer:explore -c opt
bazel-bin/rtl/producer/explore --execute --workspace="$PWD"
```

`fixtures/exp2-six-cycle.textproto` preserves the original fixture. The
handwritten `reference` target uses a separate scoreboard generated from that
fixture. Part 3's coefficient-search measurements retain their common six-cycle
implementation; Part 4 now presents the four-cycle generated circuits. Their
FP32 accuracy distributions refer to the same unchanged numerical fit.
