#include <filesystem>
#include <fstream>
#include <iostream>
#include <iterator>
#include <string>

#include "absl/flags/flag.h"
#include "absl/flags/parse.h"
#include "google/protobuf/text_format.h"
#include "rtl/producer/producer.h"

ABSL_FLAG(std::string, design, "", "NumericalDesign textproto");
ABSL_FLAG(std::string, implementation, "", "Implementation textproto");
ABSL_FLAG(std::string, output, "", "Output directory");
ABSL_FLAG(int, verify_cycles, 4096,
          "Independent integer-model comparison cycles");
namespace {
template <class T>
bool Read(const std::string& path, T* message) {
  std::ifstream f(path);
  std::string text((std::istreambuf_iterator<char>(f)), {});
  return f && google::protobuf::TextFormat::ParseFromString(text, message);
}
void Write(const std::filesystem::path& dir, const std::string& name,
           const std::string& content) {
  std::ofstream file(dir / name, std::ios::binary);
  file << content;
  if (!file) throw std::runtime_error("cannot write " + (dir / name).string());
}
}  // namespace
int main(int argc, char** argv) {
  absl::ParseCommandLine(argc, argv);
  sfu::rtl::NumericalDesign design;
  sfu::rtl::Implementation implementation;
  if (!Read(absl::GetFlag(FLAGS_design), &design) ||
      !Read(absl::GetFlag(FLAGS_implementation), &implementation))
    return 1;
  auto circuit = sfu::rtl::Lower(design, implementation);
  if (!circuit.ok()) {
    std::cerr << circuit.status() << '\n';
    return 1;
  }
  auto verified =
      sfu::rtl::Verify(*circuit, absl::GetFlag(FLAGS_verify_cycles));
  if (!verified.ok()) {
    std::cerr << verified << '\n';
    return 1;
  }
  const std::filesystem::path dir(absl::GetFlag(FLAGS_output));
  if (dir.empty()) {
    std::cerr << "--output is required\n";
    return 1;
  }
  try {
    std::filesystem::create_directories(dir);
    std::string text;
    google::protobuf::TextFormat::PrintToString(*circuit, &text);
    Write(dir, "circuit.textproto", text);
    Write(dir, "circuit.pb", circuit->SerializeAsString());
    Write(dir, "sfu_poly.sv", sfu::rtl::EmitSystemVerilog(*circuit));
    Write(dir, "pipeline.svg", sfu::rtl::EmitDiagram(*circuit));
    Write(dir, "fixture.h", sfu::rtl::EmitFixture(design));
    Write(dir, "bench.cc", sfu::rtl::EmitBench());
  } catch (const std::exception& e) {
    std::cerr << e.what() << '\n';
    return 1;
  }
  std::cout << "Generated and verified " << implementation.name() << '\n';
}
