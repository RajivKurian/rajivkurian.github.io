#include "rtl/producer/producer.h"

#include <algorithm>
#include <deque>
#include <functional>
#include <random>
#include <stdexcept>
#include <tuple>
#include <utility>

#include "absl/container/flat_hash_map.h"
#include "absl/strings/str_cat.h"
#include "absl/strings/str_format.h"
#include "sfu/fixed.h"

namespace sfu::rtl {
namespace {
using Bit = uint32_t;
using Word = std::vector<Bit>;
using Rows = std::vector<Word>;
struct Digit {
  Bit one, two, negative;
};
using Digits = std::vector<Digit>;

PipelinePlan Schedule(const NumericalDesign& d, const Implementation& i) {
  PipelinePlan p = i.pipeline();
  const bool four_cycles = d.register_stages() == 4;
  if (!p.has_operand_stage()) p.set_operand_stage(1);
  if (!p.has_first_cut_stage()) p.set_first_cut_stage(four_cycles ? 1 : 2);
  if (!p.has_first_result_stage())
    p.set_first_result_stage(four_cycles ? 2 : 3);
  if (!p.has_second_cut_stage()) p.set_second_cut_stage(four_cycles ? 3 : 4);
  return p;
}

// All arithmetic is lowered to bits before emission. Constants and transaction
// stages therefore survive changes of backend, rather than being rediscovered
// independently by the RTL writer, diagram writer and interpreter.
class Builder {
 public:
  Builder(const NumericalDesign& d, const Implementation& i) {
    *c_.mutable_design() = d;
    *c_.mutable_implementation() = i;
    New(Gate::ZERO, {}, -1);
    New(Gate::ONE, {}, -1);
  }
  Bit New(Gate::Operation op, Word args, int stage, bool reset = false) {
    auto* g = c_.add_gates();
    g->set_id(c_.gates_size() - 1);
    g->set_operation(op);
    for (Bit b : args) g->add_operands(b);
    g->set_stage(stage);
    g->set_reset_zero(reset);
    return g->id();
  }
  Bit Op(Gate::Operation op, Bit a, Bit b = 0) {
    if (op == Gate::NOT) {
      if (a < 2) return 1 - a;
      if (c_.gates(a).operation() == Gate::NOT) return c_.gates(a).operands(0);
    } else {
      if (a > b) std::swap(a, b);
      if (op == Gate::AND) {
        if (a == 0) return 0;
        if (a == 1 || a == b) return b;
      } else if (op == Gate::OR) {
        if (a == 0 || a == b) return b;
        if (a == 1) return 1;
      } else if (op == Gate::XOR) {
        if (a == b) return 0;
        if (a == 0) return b;
        if (a == 1) return Op(Gate::NOT, b);
      }
    }
    int stage = c_.gates(a).stage();
    if (op != Gate::NOT && c_.gates(b).stage() >= 0) {
      if (stage >= 0 && stage != c_.gates(b).stage())
        throw std::logic_error("operands belong to different transactions");
      stage = c_.gates(b).stage();
    }
    const std::string key = absl::StrFormat("%d:%u:%u", int(op), a, b);
    auto found = common_.find(key);
    if (found != common_.end()) return found->second;
    const Bit result = New(op, op == Gate::NOT ? Word{a} : Word{a, b}, stage);
    common_[key] = result;
    return result;
  }
  Bit Delay(Bit bit, int stage, bool reset = false) {
    if (bit < 2 && !reset) return bit;
    const int current = c_.gates(bit).stage();
    if (current == stage) return bit;
    if (current > stage) throw std::logic_error("backward transaction delay");
    const std::string key = absl::StrFormat("r:%u:%d:%d", bit, stage, reset);
    auto found = common_.find(key);
    if (found != common_.end()) return found->second;
    // Resettable constants still need an explicit stage chain.
    Bit result = bit;
    for (int s = std::max(current, 0) + 1; s <= stage; ++s)
      result = New(Gate::REGISTER, {result}, s, reset);
    common_[key] = result;
    return result;
  }
  Word Delay(Word word, int stage, bool reset = false) {
    for (auto& bit : word) bit = Delay(bit, stage, reset);
    return word;
  }
  Word Input(absl::string_view name, int width) {
    Word word;
    const auto& d = c_.design();
    for (int bit = 0; bit < width; ++bit) {
      if (name == "a" || name == "b" || name == "c") {
        auto coefficient = [&](const Coefficients& r) {
          return name == "a" ? r.a() : name == "b" ? r.b() : r.c();
        };
        const bool first = (coefficient(d.table(0)) >> bit) & 1;
        bool constant = true;
        for (const auto& r : d.table())
          constant &= bool((coefficient(r) >> bit) & 1) == first;
        if (constant) {
          word.push_back(first);
          continue;
        }
      }
      Bit id = New(Gate::INPUT, {}, 0);
      c_.mutable_gates(id)->set_input_group(std::string(name));
      c_.mutable_gates(id)->set_input_bit(bit);
      word.push_back(id);
    }
    return word;
  }
  void Signal(absl::string_view name, const WordFormat& format, const Word& w) {
    auto* s = c_.add_signals();
    s->set_name(std::string(name));
    *s->mutable_format() = format;
    for (Bit b : w) s->add_bits(b);
  }
  Bit At(const Word& w, int index) {
    return index < 0 || index >= int(w.size()) ? 0 : w[index];
  }
  Word Shift(const Word& w, int shift, int width) {
    Word out(width, 0);
    for (int j = 0; j < width; ++j) out[j] = At(w, j - shift);
    return out;
  }
  // Overlapping triples encode d = -2*hi + mid + lo, in [-2,2].
  // Only 0, +/-multiplicand and +/-2*multiplicand are needed for each row.
  Digits Decode(const Word& recoded) {
    Digits out;
    for (int j = 0; j < (int(recoded.size()) + 2) / 2; ++j) {
      Bit lo = At(recoded, 2 * j - 1), mid = At(recoded, 2 * j),
          hi = At(recoded, 2 * j + 1);
      Bit one = Op(Gate::XOR, mid, lo);
      out.push_back(
          {one, Op(Gate::AND, Op(Gate::XOR, hi, mid), Op(Gate::NOT, one)), hi});
    }
    return out;
  }
  Digits Delay(Digits digits, int stage) {
    for (auto& d : digits) {
      d.one = Delay(d.one, stage);
      d.two = Delay(d.two, stage);
      d.negative = Delay(d.negative, stage);
    }
    return digits;
  }
  // Flip the sign extension into a constant bias. All rows are added modulo
  // 2^width; width includes the full unsigned product and aligned addend, so
  // the final residue is exactly the desired nonnegative sum.
  Rows Products(const Word& multiplicand, const Digits& digits, int width) {
    Rows rows;
    Word corrections(width, 0);
    Wide bias = 0;
    const int m = multiplicand.size();
    for (int i = 0; i < int(digits.size()); ++i) {
      const auto& d = digits[i];
      Word encoded(m + 2, 0);
      for (int j = 0; j <= m; ++j) {
        Bit magnitude = Op(Gate::OR, Op(Gate::AND, d.one, At(multiplicand, j)),
                           Op(Gate::AND, d.two, At(multiplicand, j - 1)));
        encoded[j] = Op(Gate::XOR, magnitude, d.negative);
      }
      encoded[m + 1] = Op(Gate::NOT, d.negative);
      rows.push_back(Shift(encoded, 2 * i, width));
      if (2 * i < width) corrections[2 * i] = d.negative;
      if (m + 1 + 2 * i < width) bias -= Wide(1) << (m + 1 + 2 * i);
    }
    // Bias and correction columns can overlap when the recoded operand is
    // wider. They are separate addends: OR-ing them would silently lose
    // carries.
    Word constant(width, 0);
    for (int j = 0; j < width; ++j) constant[j] = (bias >> j) & 1;
    rows.push_back(corrections);
    rows.push_back(constant);
    return rows;
  }
  // Three equal-weight bits become s + 2*k. Keeping k in the next column
  // avoids propagating a carry through every column during compression.
  std::pair<Bit, Bit> FullAdder(Bit a, Bit b, Bit carry) {
    Bit p = Op(Gate::XOR, a, b);
    return {Op(Gate::XOR, p, carry),
            Op(Gate::OR, Op(Gate::AND, a, b), Op(Gate::AND, p, carry))};
  }
  Rows Layer(const Rows& rows) {
    const int width = rows.front().size();
    Rows out;
    if (c_.implementation().compression() == ROW_TREE) {
      int i = 0;
      for (; i + 2 < int(rows.size()); i += 3) {
        Word sum(width), carry(width, 0);
        for (int j = 0; j < width; ++j) {
          auto [s, k] = FullAdder(rows[i][j], rows[i + 1][j], rows[i + 2][j]);
          sum[j] = s;
          if (j + 1 < width) carry[j + 1] = k;
        }
        out.push_back(sum);
        out.push_back(carry);
      }
      for (; i < int(rows.size()); ++i) out.push_back(rows[i]);
    } else {
      // Pack columns independently. Sparse sign/correction rows need not force
      // empty bit positions through the same whole-word grouping.
      std::vector<Word> columns(width);
      for (int j = 0; j < width; ++j) {
        Word bits;
        for (const auto& row : rows)
          if (row[j] != 0) bits.push_back(row[j]);
        int i = 0;
        for (; i + 2 < int(bits.size()); i += 3) {
          auto [s, k] = FullAdder(bits[i], bits[i + 1], bits[i + 2]);
          if (s) columns[j].push_back(s);
          if (j + 1 < width && k) columns[j + 1].push_back(k);
        }
        for (; i < int(bits.size()); ++i) columns[j].push_back(bits[i]);
      }
      size_t height = 2;
      for (const auto& col : columns) height = std::max(height, col.size());
      out.assign(height, Word(width, 0));
      for (int j = 0; j < width; ++j)
        for (int i = 0; i < int(columns[j].size()); ++i)
          out[i][j] = columns[j][i];
    }
    return out;
  }
  Rows Compress(Rows rows, int layers = 0) {
    for (int i = 0; rows.size() > 2 && (!layers || i < layers); ++i)
      rows = Layer(rows);
    while (rows.size() < 2) rows.push_back(Word(rows.front().size(), 0));
    return rows;
  }
  Word Add(Word a, Word b, Bit carry = 0, const AdderPlan& plan = AdderPlan()) {
    const int width = a.size();
    const CarryAdder kind = plan.kind() == CARRY_ADDER_UNSPECIFIED
                                ? c_.implementation().carry_adder()
                                : plan.kind();
    Word out(width);
    if (kind == RIPPLE || kind == HYBRID) {
      const int end =
          kind == RIPPLE ? width : std::min(width, int(plan.ripple_bits()));
      for (int j = 0; j < end; ++j) {
        auto [sum, next] = FullAdder(a[j], b[j], carry);
        out[j] = sum;
        carry = next;
      }
      if (end == width) return out;
      AdderPlan prefix;
      prefix.set_kind(PREFIX);
      Word upper = Add(Word(a.begin() + end, a.end()),
                       Word(b.begin() + end, b.end()), carry, prefix);
      std::copy(upper.begin(), upper.end(), out.begin() + end);
      return out;
    }
    Word p(width), g(width);
    for (int j = 0; j < width; ++j) {
      p[j] = Op(Gate::XOR, a[j], b[j]);
      g[j] = Op(Gate::AND, a[j], b[j]);
    }
    if (kind == BLOCK_LOOKAHEAD) {
      const int block = plan.block_bits();
      const int count = (width + block - 1) / block;
      Word gp(count, 1), gg(count, 0);
      for (int k = 0; k < count; ++k)
        for (int j = k * block; j < std::min(width, (k + 1) * block); ++j) {
          gg[k] = Op(Gate::OR, g[j], Op(Gate::AND, p[j], gg[k]));
          gp[k] = Op(Gate::AND, p[j], gp[k]);
        }
      for (int stride = 1; stride < count; stride *= 2) {
        Word np = gp, ng = gg;
        for (int k = stride; k < count; ++k) {
          ng[k] = Op(Gate::OR, gg[k], Op(Gate::AND, gp[k], gg[k - stride]));
          np[k] = Op(Gate::AND, gp[k], gp[k - stride]);
        }
        gp = std::move(np);
        gg = std::move(ng);
      }
      for (int k = 0; k < count; ++k) {
        Bit incoming =
            k == 0 ? carry
                   : Op(Gate::OR, gg[k - 1], Op(Gate::AND, gp[k - 1], carry));
        for (int j = k * block; j < std::min(width, (k + 1) * block); ++j) {
          auto [sum, next] = FullAdder(a[j], b[j], incoming);
          out[j] = sum;
          incoming = next;
        }
      }
      return out;
    }
    const Word original = p;
    for (int stride = 1; stride < width; stride *= 2) {
      Word next_p = p, next_g = g;
      for (int j = stride; j < width; ++j) {
        next_g[j] = Op(Gate::OR, g[j], Op(Gate::AND, p[j], g[j - stride]));
        next_p[j] = Op(Gate::AND, p[j], p[j - stride]);
      }
      p = std::move(next_p);
      g = std::move(next_g);
    }
    for (int j = 0; j < width; ++j) {
      Bit incoming =
          j == 0 ? carry
                 : Op(Gate::OR, g[j - 1], Op(Gate::AND, p[j - 1], carry));
      out[j] = Op(Gate::XOR, original[j], incoming);
    }
    return out;
  }
  // A cut inside the carry network stores partial group summaries and the
  // original XOR bits. Later levels resume the same associative prefix scan.
  Word PrefixCheckpoint(const Word& a, const Word& b, int levels, int stage) {
    const int width = a.size();
    Word p(width), g(width);
    for (int j = 0; j < width; ++j) {
      p[j] = Op(Gate::XOR, a[j], b[j]);
      g[j] = Op(Gate::AND, a[j], b[j]);
    }
    Word original = p;
    int stride = 1;
    auto level = [&] {
      Word np = p, ng = g;
      for (int j = stride; j < width; ++j) {
        ng[j] = Op(Gate::OR, g[j], Op(Gate::AND, p[j], g[j - stride]));
        np[j] = Op(Gate::AND, p[j], p[j - stride]);
      }
      p = std::move(np);
      g = std::move(ng);
      stride *= 2;
    };
    for (int n = 0; n < levels && stride < width; ++n) level();
    p = Delay(p, stage);
    g = Delay(g, stage);
    original = Delay(original, stage);
    while (stride < width) level();
    Word sum(width);
    for (int j = 0; j < width; ++j)
      sum[j] = Op(Gate::XOR, original[j], j == 0 ? 0 : g[j - 1]);
    return sum;
  }
  struct Completed {
    Word retained;
    Bit guard;
    Bit sticky;
  };
  Completed CutAndComplete(Rows rows, int drop, int width, int cut_stage,
                           const MacPlan& plan) {
    const auto& i = c_.implementation();
    const int layers = plan.has_compression_layers_before_cut()
                           ? plan.compression_layers_before_cut()
                           : i.compression_layers_before_cut();
    rows = Compress(std::move(rows), layers);
    Word sum;
    Bit guard = 0, sticky = 0;
    // Dropped columns still affect the retained word through one carry.
    // RNE additionally needs guard and sticky. Storing these summaries moves
    // exact work across the cut without adding a numerical rounding point.
    const int resolved =
        plan.has_resolved_columns()
            ? plan.resolved_columns()
            : (i.resolve_low_columns() ? std::max(0, drop) : 0);
    if (plan.has_prefix_levels_before_cut()) {
      Word full = PrefixCheckpoint(rows[0], rows[1],
                                   plan.prefix_levels_before_cut(), cut_stage);
      if (drop > 0) {
        guard = full[drop - 1];
        for (int j = 0; j < drop - 1; ++j)
          sticky = Op(Gate::OR, sticky, full[j]);
      }
      sum = Shift(full, -drop, full.size() + std::max(0, -drop));
    } else if (resolved > 0 && resolved != drop) {
      // Complete k low columns exactly, even when k crosses the narrowing
      // boundary. Retained low bits and the carry still belong to this input.
      const int k = std::min(resolved, int(rows[0].size()));
      Word low_a(rows[0].begin(), rows[0].begin() + k);
      Word low_b(rows[1].begin(), rows[1].begin() + k);
      low_a.push_back(0);
      low_b.push_back(0);
      Word low = Add(low_a, low_b, 0, plan.low_adder());
      Word high =
          Add(Delay(Word(rows[0].begin() + k, rows[0].end()), cut_stage),
              Delay(Word(rows[1].begin() + k, rows[1].end()), cut_stage),
              Delay(low[k], cut_stage), plan.high_adder());
      Word full = Delay(Word(low.begin(), low.begin() + k), cut_stage);
      full.insert(full.end(), high.begin(), high.end());
      if (drop > 0) {
        guard = full[drop - 1];
        for (int j = 0; j < drop - 1; ++j)
          sticky = Op(Gate::OR, sticky, full[j]);
      }
      sum = Shift(full, -drop, full.size() + std::max(0, -drop));
    } else if (resolved > 0 && drop > 0) {
      Word low_a(rows[0].begin(), rows[0].begin() + drop);
      Word low_b(rows[1].begin(), rows[1].begin() + drop);
      low_a.push_back(0);
      low_b.push_back(0);
      Word low = Add(low_a, low_b, 0, plan.low_adder());
      Word high_a(rows[0].begin() + drop, rows[0].end());
      Word high_b(rows[1].begin() + drop, rows[1].end());
      Bit carry = Delay(low[drop], cut_stage);
      guard = Delay(low[drop - 1], cut_stage);
      for (int j = 0; j < drop - 1; ++j) sticky = Op(Gate::OR, sticky, low[j]);
      sticky = Delay(sticky, cut_stage);
      sum = Add(Delay(high_a, cut_stage), Delay(high_b, cut_stage), carry,
                plan.high_adder());
    } else {
      for (auto& row : rows) row = Delay(row, cut_stage);
      rows = Compress(std::move(rows));
      Word full = Add(rows[0], rows[1], 0, plan.high_adder());
      if (drop > 0) {
        guard = full[drop - 1];
        for (int j = 0; j < drop - 1; ++j)
          sticky = Op(Gate::OR, sticky, full[j]);
      }
      sum = Shift(full, -drop, full.size() + std::max(0, -drop));
    }
    sum.resize(width, 0);
    return {sum, guard, sticky};
  }
  Word Narrow(Completed result, Narrowing mode) {
    if (mode == TRUNCATE) return result.retained;
    Bit increment = Op(Gate::AND, result.guard,
                       Op(Gate::OR, result.sticky, result.retained[0]));
    return Add(result.retained, Word(result.retained.size(), 0), increment);
  }
  Rows Heap(absl::string_view name, const Word& u, const WordFormat& uf,
            const Word& t, const WordFormat& tf, const Word& addend,
            const WordFormat& bf, const Digits& shared) {
    const int pf = uf.fraction() + tf.fraction();
    const int common = std::max(pf, int(bf.fraction()));
    const int width =
        std::max(int(u.size() + t.size()) + common - pf,
                 int(addend.size()) + common - int(bf.fraction())) +
        1;
    bool residual =
        c_.implementation().recoding() == RESIDUAL || t.size() < u.size();
    const Word& multiplicand = residual ? u : t;
    const Word& recoded = residual ? t : u;
    Digits digits = shared.empty() ? Decode(recoded) : shared;
    Rows rows = Products(multiplicand, digits, width);
    for (auto& row : rows) row = Shift(row, common - pf, width);
    rows.insert(rows.begin(), Shift(addend, common - bf.fraction(), width));
    auto* heap = c_.add_heaps();
    heap->set_name(std::string(name));
    heap->set_width(width);
    heap->set_fraction(common);
    // Rows retain column identity for drawing and analysis.
    heap->clear_rows();
    for (const auto& row : rows) {
      auto* r = heap->add_rows();
      for (Bit b : row) r->add_bits(b);
    }
    return rows;
  }
  // Register placement belongs to the implementation. The first and final
  // narrowing still evaluate the same integer functions for every schedule.
  Circuit Build() {
    const auto d = c_.design();
    Word a = Input("a", d.a().width()), b = Input("b", d.b().width());
    Word c = Input("c", d.c().width()), t = Input("x", d.t().width());
    Bit valid = Input("valid", 1)[0];
    Signal("a", d.a(), a);
    Signal("b", d.b(), b);
    Signal("c", d.c(), c);
    Signal("t", d.t(), t);
    const auto pipeline = Schedule(d, c_.implementation());
    const int operand_stage = pipeline.operand_stage();
    const int first_cut = pipeline.first_cut_stage();
    const int first_result = pipeline.first_result_stage();
    const int second_cut = pipeline.second_cut_stage();
    const int retained_stage = d.register_stages() - 1;
    Digits shared;
    if (c_.implementation().decode_storage() == CARRIED) shared = Decode(t);
    a = Delay(a, operand_stage);
    b = Delay(b, operand_stage);
    c = Delay(c, operand_stage);
    t = Delay(t, operand_stage);
    shared = Delay(shared, operand_stage);
    Rows first = Heap("a*t+b", a, d.a(), t, d.t(), b, d.b(), shared);
    const int f1 = c_.heaps(0).fraction();
    Word s =
        Delay(Narrow(CutAndComplete(first, f1 - d.s().fraction(), d.s().width(),
                                    first_cut, c_.implementation().first_mac()),
                     d.first_rounding()),
              first_result);
    Signal("s", d.s(), s);
    t = Delay(t, first_result);
    c = Delay(c, first_result);
    shared = Delay(shared, first_result);
    Rows second = Heap("s*t+c", s, d.s(), t, d.t(), c, d.c(), shared);
    const int f2 = c_.heaps(1).fraction();
    Completed y = CutAndComplete(second, f2 - d.y().fraction(), d.y().width(),
                                 second_cut, c_.implementation().second_mac());
    y.retained = Delay(y.retained, retained_stage);
    y.guard = Delay(y.guard, retained_stage);
    y.sticky = Delay(y.sticky, retained_stage);
    Word output =
        Delay(Narrow(y, d.second_rounding()), d.register_stages(), true);
    Signal("y", d.y(), output);
    for (Bit bit : output) c_.add_output_bits(bit);
    c_.set_output_valid(Delay(valid, d.register_stages(), true));
    std::function<void(Bit)> visit = [&](Bit id) {
      if (c_.gates(id).live()) return;
      c_.mutable_gates(id)->set_live(true);
      const auto operands = c_.gates(id).operands();
      for (Bit arg : operands) visit(arg);
    };
    for (Bit bit : output) visit(bit);
    visit(c_.output_valid());
    return std::move(c_);
  }

 private:
  Circuit c_;
  absl::flat_hash_map<std::string, Bit> common_;
};
Format ToFormat(const WordFormat& f) {
  return {int(f.width()), int(f.fraction())};
}
Rounding Mode(Narrowing n) {
  return n == RNE ? Rounding::kNearestEven : Rounding::kTruncate;
}
}  // namespace

absl::Status Validate(const NumericalDesign& d, const Implementation& i) {
  auto error = [](absl::string_view text) {
    return absl::InvalidArgumentError(text);
  };
  if (d.schema_version() != 1 || i.schema_version() != 1)
    return error("schema_version must be 1");
  if (d.table_size() < 2 || (d.table_size() & (d.table_size() - 1)))
    return error("table size must be a power of two >= 2");
  for (const auto* f : {&d.a(), &d.b(), &d.c(), &d.t(), &d.s(), &d.y()})
    if (f->width() < 1 || f->width() > 32 || f->fraction() > 60)
      return error("formats require widths 1..32 and fractions 0..60");
  for (const auto& r : d.table())
    if ((r.a() >> d.a().width()) || (r.b() >> d.b().width()) ||
        (r.c() >> d.c().width()))
      return error("coefficient exceeds declared width");
  if ((d.first_rounding() != RNE && d.first_rounding() != TRUNCATE) ||
      (d.second_rounding() != RNE && d.second_rounding() != TRUNCATE))
    return error("choose both narrowing rules");
  for (auto [u, addend, result] :
       std::vector<std::tuple<WordFormat, WordFormat, WordFormat>>{
           {d.a(), d.b(), d.s()}, {d.s(), d.c(), d.y()}}) {
    const int product_fraction = u.fraction() + d.t().fraction();
    const int common = std::max(product_fraction, int(addend.fraction()));
    const int width =
        std::max(int(u.width() + d.t().width()) + common - product_fraction,
                 int(addend.width()) + common - int(addend.fraction())) +
        1;
    if (common > 120 || width > 126)
      return error("aligned sum exceeds 126 scratch bits");
    if (common - int(result.fraction()) >= width)
      return error("narrowing discards the entire aligned sum");
  }
  if (d.register_stages() < 3 || d.register_stages() > 6)
    return error("choose three to six register stages");
  const auto pipeline = Schedule(d, i);
  const int operand = pipeline.operand_stage();
  const int cut1 = pipeline.first_cut_stage();
  const int result1 = pipeline.first_result_stage();
  const int cut2 = pipeline.second_cut_stage();
  if (operand > cut1 || cut1 >= result1 || result1 > cut2 ||
      cut2 >= int(d.register_stages()))
    return error(
        "schedule requires operand <= cut1 < result1 <= cut2 < output");
  if ((i.recoding() != NARROW_OPERAND && i.recoding() != RESIDUAL) ||
      (i.decode_storage() != LOCAL && i.decode_storage() != CARRIED) ||
      (i.compression() != ROW_TREE && i.compression() != COLUMN_GREEDY) ||
      (i.carry_adder() != RIPPLE && i.carry_adder() != PREFIX))
    return error(
        "choose recoding, decode storage, compression and carry adder");
  if (i.decode_storage() == CARRIED && i.recoding() != RESIDUAL)
    return error("carried decoding requires residual recoding");
  for (const auto* plan : {&i.first_mac(), &i.second_mac()}) {
    const int layers = plan->has_compression_layers_before_cut()
                           ? plan->compression_layers_before_cut()
                           : i.compression_layers_before_cut();
    const bool resolves = plan->has_resolved_columns()
                              ? plan->resolved_columns() > 0
                              : i.resolve_low_columns();
    if (layers && (resolves || plan->has_prefix_levels_before_cut()))
      return error(
          "low resolution and prefix checkpoints require complete compression");
    if (plan->resolved_columns() > 126 || plan->prefix_levels_before_cut() > 8)
      return error("cut exceeds the aligned-word limits");
    if (plan->has_prefix_levels_before_cut() && plan->has_resolved_columns())
      return error("select a resolved-column cut or a prefix checkpoint");
    for (const auto* adder : {&plan->low_adder(), &plan->high_adder()}) {
      if (adder->kind() < CARRY_ADDER_UNSPECIFIED ||
          adder->kind() > BLOCK_LOOKAHEAD)
        return error("invalid adder kind");
      if (adder->kind() == HYBRID && adder->ripple_bits() > 126)
        return error("hybrid ripple span exceeds 126 bits");
      if (adder->kind() == BLOCK_LOOKAHEAD &&
          (adder->block_bits() < 2 || adder->block_bits() > 32))
        return error("lookahead block width must be 2..32");
    }
  }
  return absl::OkStatus();
}
absl::StatusOr<Circuit> Lower(const NumericalDesign& d,
                              const Implementation& i) {
  auto status = Validate(d, i);
  if (!status.ok()) return status;
  try {
    return Builder(d, i).Build();
  } catch (const std::exception& e) {
    return absl::InternalError(e.what());
  }
}
Simulator::Simulator(const Circuit& c)
    : circuit_(c), registers_(c.gates_size()), values_(c.gates_size()) {}
void Simulator::Evaluate(uint32_t row, uint64_t residual, bool valid) {
  const auto& r = circuit_.design().table(row);
  for (const auto& g : circuit_.gates()) {
    bool result = false;
    auto arg = [&](int j) { return values_[g.operands(j)]; };
    switch (g.operation()) {
      case Gate::ZERO:
        break;
      case Gate::ONE:
        result = true;
        break;
      case Gate::INPUT: {
        uint64_t word = g.input_group() == "a"   ? r.a()
                        : g.input_group() == "b" ? r.b()
                        : g.input_group() == "c" ? r.c()
                        : g.input_group() == "x" ? residual
                                                 : valid;
        result = (word >> g.input_bit()) & 1;
        break;
      }
      case Gate::XOR:
        result = arg(0) != arg(1);
        break;
      case Gate::AND:
        result = arg(0) && arg(1);
        break;
      case Gate::OR:
        result = arg(0) || arg(1);
        break;
      case Gate::NOT:
        result = !arg(0);
        break;
      case Gate::REGISTER:
        result = registers_[g.id()];
        break;
      default:
        throw std::logic_error("unknown gate");
    }
    values_[g.id()] = result;
  }
}
Simulator::Output Simulator::Tick(uint32_t row, uint64_t residual, bool valid,
                                  bool reset) {
  Evaluate(row, residual, valid);
  // Read all D values from the pre-edge evaluation. Updating one register
  // must never let a later register see the new transaction on the same edge.
  for (const auto& g : circuit_.gates())
    if (g.operation() == Gate::REGISTER)
      registers_[g.id()] = !(reset && g.reset_zero()) && values_[g.operands(0)];
  Evaluate(row, residual, valid);
  Output out{values_[circuit_.output_valid()], 0};
  for (int j = 0; j < circuit_.output_bits_size(); ++j)
    out.value |= uint64_t(values_[circuit_.output_bits(j)]) << j;
  return out;
}
absl::Status Verify(const Circuit& c, int cycles) {
  Simulator sim(c);
  const auto& d = c.design();
  std::deque<Simulator::Output> queue(d.register_stages() - 1, {false, 0});
  std::mt19937_64 random(0x535655);
  const uint64_t mask = (uint64_t(1) << d.t().width()) - 1;
  try {
    for (int j = 0; j < cycles + 8; ++j) {
      bool reset = j < 2 || j == cycles / 2;
      uint32_t row = j % d.table_size();
      uint64_t t = j % 5 == 0 ? 0 : j % 5 == 1 ? mask : random() & mask;
      bool valid = j < cycles && j % 7 != 0;
      const auto& r = d.table(row);
      Fixed x(t, ToFormat(d.t()));
      Fixed s = MultiplyAdd(Fixed(r.a(), ToFormat(d.a())), x,
                            Fixed(r.b(), ToFormat(d.b())), ToFormat(d.s()),
                            Mode(d.first_rounding()));
      Fixed y = MultiplyAdd(s, x, Fixed(r.c(), ToFormat(d.c())),
                            ToFormat(d.y()), Mode(d.second_rounding()));
      auto actual = sim.Tick(row, t, valid, reset);
      if (reset) {
        queue.assign(d.register_stages() - 1, {false, 0});
        if (actual.valid || actual.value)
          return absl::InternalError("reset did not flush output");
      } else {
        auto expected = queue.front();
        queue.pop_front();
        queue.push_back({valid, y.raw()});
        if (actual.valid != expected.valid ||
            (expected.valid && actual.value != expected.value))
          return absl::InternalError(absl::StrFormat(
              "cycle %d: expected valid=%d value=%u, got valid=%d value=%u", j,
              expected.valid, expected.value, actual.valid, actual.value));
      }
    }
  } catch (const std::exception& e) {
    return absl::InvalidArgumentError(e.what());
  }
  return absl::OkStatus();
}
}  // namespace sfu::rtl
