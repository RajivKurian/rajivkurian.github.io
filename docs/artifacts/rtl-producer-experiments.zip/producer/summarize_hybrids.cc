#include <algorithm>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <iterator>
#include <stdexcept>
#include <string>
#include <vector>

#include "absl/strings/str_cat.h"
#include "absl/strings/str_format.h"
#include "google/protobuf/struct.pb.h"
#include "google/protobuf/text_format.h"
#include "google/protobuf/util/json_util.h"
#include "rtl/producer/schema.pb.h"

namespace {
namespace fs = std::filesystem;
using google::protobuf::Struct;
using google::protobuf::Value;
struct Point {
  std::string name;
  int latency, ff;
  double area, slack, power;
  bool global = false, local = false, timing = false;
};
std::string Read(const fs::path& path) {
  std::ifstream f(path);
  return {(std::istreambuf_iterator<char>(f)), {}};
}
const Value& Get(const Struct& s, const std::string& name) {
  return s.fields().at(name);
}
bool Dominates(const Point& a, const Point& b, bool same_latency,
               bool compare_slack = false) {
  if (same_latency && a.latency != b.latency) return false;
  return a.latency <= b.latency && a.area <= b.area && a.power <= b.power &&
         (!compare_slack || a.slack >= b.slack) &&
         (a.latency < b.latency || a.area < b.area || a.power < b.power ||
          (compare_slack && a.slack > b.slack));
}
std::string Row(const Point& p) {
  return absl::StrFormat("| %s | %d | %.3f | %.2f | %.4f | %d |\n", p.name,
                         p.latency, p.area, p.slack, p.power, p.ff);
}
const char* kHeader =
    "| Circuit | Cycles | Area (µm²) | Slack (ps) | Power (mW) | FFs "
    "|\n|---|---:|---:|---:|---:|---:|\n";
}  // namespace
int main() {
  try {
    const fs::path root = "rtl/producer/hybrid_search/results";
    std::vector<Point> points;
    std::string context;
    for (const auto& entry : fs::directory_iterator(root / "completed")) {
      const auto base = entry.path();
      if (base.filename().string().ends_with(".pending") ||
          !fs::exists(base / "context.txt"))
        continue;
      const auto this_context = Read(base / "context.txt");
      if (context.empty()) context = this_context;
      if (this_context != context)
        throw std::runtime_error("mixed production contexts");
      Struct report;
      if (!google::protobuf::util::JsonStringToMessage(
               Read(base / "reports/summary.json"), &report)
               .ok())
        throw std::runtime_error("invalid report");
      sfu::rtl::Circuit circuit;
      if (!google::protobuf::TextFormat::ParseFromString(
              Read(base / "generated/circuit.textproto"), &circuit))
        throw std::runtime_error("invalid circuit");
      Struct stats;
      if (!google::protobuf::util::JsonStringToMessage(
               Read(base / "mapped/statistics.json"), &stats)
               .ok())
        throw std::runtime_error("invalid stats");
      int ff = 0;
      for (const auto& item :
           Get(Get(stats, "design").struct_value(), "num_cells_by_type")
               .struct_value()
               .fields())
        if (item.first.find("DFF") != std::string::npos)
          ff += item.second.number_value();
      const auto& power =
          Get(Get(Get(report, "power").struct_value(), "Total").struct_value(),
              "total");
      points.push_back({entry.path().filename().string(),
                        int(circuit.design().register_stages()), ff,
                        Get(report, "cell_area_um2").number_value(),
                        Get(report, "worst_setup_slack_ps").number_value(),
                        power.number_value() * 1000});
    }
    std::sort(points.begin(), points.end(), [](const Point& a, const Point& b) {
      return a.latency != b.latency ? a.latency < b.latency : a.area < b.area;
    });
    for (auto& p : points) {
      if (p.slack < 0) continue;
      p.global = p.local = p.timing = true;
      for (const auto& q : points) {
        if (q.slack < 0) continue;
        if (Dominates(q, p, false)) p.global = false;
        if (Dominates(q, p, true)) p.local = false;
        if (Dominates(q, p, false, true)) p.timing = false;
      }
    }
    std::string summary = "# Measured hybrid/cut exploration\n\n";
    absl::StrAppend(
        &summary, points.size(),
        " checked circuits; mapped cells and pin loads, ASAP7 RVT TT, 1000 ps "
        "clock.\n\n## Smallest passing circuit at each latency\n\n",
        kHeader);
    for (int latency = 3; latency <= 6; ++latency) {
      auto found = std::find_if(
          points.begin(), points.end(),
          [&](const Point& p) { return p.latency == latency && p.slack >= 0; });
      if (found != points.end()) absl::StrAppend(&summary, Row(*found));
    }
    absl::StrAppend(
        &summary,
        "\n## Area / power / latency frontier at 1 ns\n\n"
        "Nonnegative setup slack is a feasibility requirement here. "
        "Additional slack does not offset area or power.\n\n",
        kHeader);
    for (const auto& p : points)
      if (p.global) absl::StrAppend(&summary, Row(p));
    absl::StrAppend(&summary, "\n## Frontier within each latency\n\n", kHeader);
    for (const auto& p : points)
      if (p.local) absl::StrAppend(&summary, Row(p));
    absl::StrAppend(&summary,
                    "\n## Alternatives retaining more timing margin\n\n",
                    kHeader);
    for (const auto& p : points)
      if (p.timing) absl::StrAppend(&summary, Row(p));
    absl::StrAppend(&summary, "\n## All measurements\n\n", kHeader);
    for (const auto& p : points) absl::StrAppend(&summary, Row(p));
    std::ofstream(root / "summary.md") << summary;
    Struct result;
    auto* rows =
        (*result.mutable_fields())["measurements"].mutable_list_value();
    for (const auto& p : points) {
      auto& f = *rows->add_values()->mutable_struct_value()->mutable_fields();
      f["name"].set_string_value(p.name);
      f["latency"].set_number_value(p.latency);
      f["area_um2"].set_number_value(p.area);
      f["slack_ps"].set_number_value(p.slack);
      f["power_mw"].set_number_value(p.power);
      f["flip_flops"].set_number_value(p.ff);
      f["global_frontier"].set_bool_value(p.global);
      f["latency_frontier"].set_bool_value(p.local);
      f["timing_frontier"].set_bool_value(p.timing);
    }
    std::string json;
    google::protobuf::util::JsonPrintOptions options;
    options.add_whitespace = true;
    if (!google::protobuf::util::MessageToJsonString(result, &json, options)
             .ok())
      throw std::runtime_error("cannot encode summary");
    std::ofstream(root / "summary.json") << json;
    std::cout << "Summarized " << points.size() << " measured circuits.\n";
  } catch (const std::exception& e) {
    std::cerr << e.what() << '\n';
    return 1;
  }
}
