#include <fcntl.h>
#include <spawn.h>
#include <sys/wait.h>
#include <unistd.h>

#include <algorithm>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <iterator>
#include <map>
#include <stdexcept>
#include <string>
#include <vector>

#include "absl/container/flat_hash_map.h"
#include "absl/flags/flag.h"
#include "absl/flags/parse.h"
#include "absl/strings/str_cat.h"
#include "absl/strings/str_replace.h"
#include "google/protobuf/struct.pb.h"
#include "google/protobuf/util/json_util.h"

ABSL_FLAG(std::string, mapped, "", "Mapped output directory");
ABSL_FLAG(std::string, tools, "bazel-code/external/+_repo_rules4+eda_tools",
          "Pinned EDA runtime");
ABSL_FLAG(std::string, output, "", "Separate audit directory");
extern char** environ;
namespace {
namespace fs = std::filesystem;
using google::protobuf::Struct;
using google::protobuf::Value;
std::string Read(const fs::path& p) {
  std::ifstream f(p);
  if (!f) throw std::runtime_error("cannot read " + p.string());
  return {(std::istreambuf_iterator<char>(f)), {}};
}
void Write(const fs::path& p, const std::string& value) {
  std::ofstream(p) << value;
}
const Value& Get(const Struct& s, const std::string& name) {
  return s.fields().at(name);
}
std::string Quote(const fs::path& p) {
  return "\"" +
         absl::StrReplaceAll(p.string(), {{"\\", "\\\\"}, {"\"", "\\\""}}) +
         "\"";
}
void Run(std::vector<std::string> args, const fs::path& log) {
  posix_spawn_file_actions_t actions;
  posix_spawn_file_actions_init(&actions);
  posix_spawn_file_actions_addopen(&actions, STDOUT_FILENO, log.c_str(),
                                   O_WRONLY | O_CREAT | O_TRUNC, 0644);
  posix_spawn_file_actions_adddup2(&actions, STDOUT_FILENO, STDERR_FILENO);
  std::vector<char*> argv;
  for (auto& a : args) argv.push_back(a.data());
  argv.push_back(nullptr);
  pid_t pid;
  int status =
      posix_spawn(&pid, argv[0], &actions, nullptr, argv.data(), environ);
  posix_spawn_file_actions_destroy(&actions);
  if (status || waitpid(pid, &status, 0) < 0 || !WIFEXITED(status) ||
      WEXITSTATUS(status))
    throw std::runtime_error("audit command failed; see " + log.string());
}
}  // namespace
int main(int argc, char** argv) {
  absl::ParseCommandLine(argc, argv);
  try {
    const auto mapped = fs::canonical(absl::GetFlag(FLAGS_mapped));
    const auto tools = fs::canonical(absl::GetFlag(FLAGS_tools));
    const auto output = fs::absolute(absl::GetFlag(FLAGS_output));
    fs::create_directories(output);
    unsetenv("DYLD_LIBRARY_PATH");
    unsetenv("LD_LIBRARY_PATH");
    setenv("TCL_LIBRARY", (tools / "lib/tcl8.6").c_str(), 1);
    const auto script = output / "observe.ys";
    Write(script, "read_liberty -lib -ignore_miss_func " +
                      Quote(mapped / "asap7.lib") + "\nread_verilog " +
                      Quote(mapped / "netlist.v") +
                      "\nhierarchy -top sfu_poly\nwrite_json " +
                      Quote(output / "netlist.json") + "\n");
    // Reading the already mapped netlist in another process avoids perturbing
    // ABC's ordering or production mapping while recovering connectivity.
    Run({(tools / "bin/yosys").string(), "-s", script.string()},
        output / "observe.log");
    Struct root;
    auto status = google::protobuf::util::JsonStringToMessage(
        Read(output / "netlist.json"), &root);
    if (!status.ok()) throw std::runtime_error("invalid observed netlist JSON");
    const auto& module =
        Get(Get(root, "modules").struct_value(), "sfu_poly").struct_value();
    absl::flat_hash_map<int, int> stage;
    for (const auto& item : Get(module, "ports").struct_value().fields())
      if (Get(item.second.struct_value(), "direction").string_value() ==
          "input")
        for (const auto& bit :
             Get(item.second.struct_value(), "bits").list_value().values())
          if (bit.kind_case() == Value::kNumberValue)
            stage[bit.number_value()] = 0;
    const auto& cells = Get(module, "cells").struct_value().fields();
    std::map<int, std::vector<std::string>> endpoints;
    absl::flat_hash_map<std::string, bool> done;
    bool progress = true;
    while (progress) {
      progress = false;
      for (const auto& item : cells) {
        if (done[item.first]) continue;
        const auto& c = item.second.struct_value();
        const bool ff =
            Get(c, "type").string_value().find("DFF") != std::string::npos;
        const auto& connections = Get(c, "connections").struct_value();
        const auto& directions = Get(c, "port_directions").struct_value();
        int incoming = 0;
        bool ready = true;
        for (const auto& port : connections.fields()) {
          if (Get(directions, port.first).string_value() != "input" ||
              (ff && port.first != "D"))
            continue;
          for (const auto& bit : port.second.list_value().values()) {
            if (bit.kind_case() != Value::kNumberValue) continue;
            auto found = stage.find(bit.number_value());
            if (found == stage.end())
              ready = false;
            else
              incoming = std::max(incoming, found->second);
          }
        }
        if (!ready) continue;
        const int current = incoming + int(ff);
        for (const auto& port : connections.fields())
          if (Get(directions, port.first).string_value() == "output")
            for (const auto& bit : port.second.list_value().values())
              if (bit.kind_case() == Value::kNumberValue)
                stage[bit.number_value()] = current;
        if (ff) endpoints[current].push_back(item.first + "/D");
        done[item.first] = true;
        progress = true;
      }
    }
    if (std::count_if(done.begin(), done.end(),
                      [](const auto& e) { return e.second; }) != cells.size())
      throw std::runtime_error("unresolved sequential connectivity");
    std::string tcl = "read_liberty {" + (mapped / "asap7.lib").string() +
                      "}\nread_verilog {" + (mapped / "netlist.v").string() +
                      "}\nlink_design sfu_poly\nread_sdc {" +
                      fs::absolute("rtl/producer/polynomial.sdc").string() +
                      "}\n";
    for (auto& [depth, pins] : endpoints) {
      std::sort(pins.begin(), pins.end());
      absl::StrAppend(&tcl, "puts {SEQUENTIAL_DEPTH ", depth, " ENDPOINTS ",
                      pins.size(), "}\nreport_checks -to [get_pins {");
      for (const auto& pin : pins) absl::StrAppend(&tcl, pin, " ");
      absl::StrAppend(
          &tcl, "}] -path_delay max -format full_clock_expanded -digits 4\n");
    }
    // Depth is the longest number of FF boundaries from primary inputs. Reset-
    // only constant output bits can have smaller depth than their valid stream.
    Write(output / "stage_paths.tcl", tcl);
    Run({(tools / "bin/sta").string(), "-no_init", "-exit",
         (output / "stage_paths.tcl").string()},
        output / "stage_paths.log");
    std::cout << "Audited " << done.size() << " mapped cells across "
              << endpoints.size() << " sequential-depth groups.\n";
  } catch (const std::exception& e) {
    std::cerr << e.what() << '\n';
    return 1;
  }
}
