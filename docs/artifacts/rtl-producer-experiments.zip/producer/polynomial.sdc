# ASAP7 libraries use ps and fF. A 1000 ps period is a 1 GHz target.
create_clock -name core -period 1000 [get_ports clk]
set data_inputs [all_inputs -no_clocks]
set_clock_uncertainty 20 [get_clocks core]
set_input_delay 100 -clock core $data_inputs
set_output_delay 100 -clock core [get_ports {out_valid y*}]
set_input_transition 20 $data_inputs
set_load 2 [get_ports {out_valid y*}]
