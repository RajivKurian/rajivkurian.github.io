// A 3:2 compressor replaces three rows by two without propagating a carry
// along the word. Each bit computes a parity bit and a majority bit; majority
// moves one column to the left because a carry has twice the positional weight.
module carry_save_layer #(
    parameter integer WIDTH = 38,
    parameter integer INPUT_ROWS = 3
) (
    input wire [INPUT_ROWS*WIDTH-1:0] rows_in,
    output wire [(2*(INPUT_ROWS/3)+INPUT_ROWS%3)*WIDTH-1:0] rows_out
);
    localparam integer GROUPS = INPUT_ROWS / 3;
    localparam integer LEFTOVER = INPUT_ROWS % 3;
    genvar group_index;
    generate
        for (group_index = 0; group_index < GROUPS; group_index = group_index + 1) begin : compress
            wire [WIDTH-1:0] a = rows_in[(3*group_index)*WIDTH +: WIDTH];
            wire [WIDTH-1:0] b = rows_in[(3*group_index+1)*WIDTH +: WIDTH];
            wire [WIDTH-1:0] c = rows_in[(3*group_index+2)*WIDTH +: WIDTH];
            assign rows_out[(2*group_index)*WIDTH +: WIDTH] = a ^ b ^ c;
            assign rows_out[(2*group_index+1)*WIDTH +: WIDTH] =
                ((a & b) | (a & c) | (b & c)) << 1;
        end
        for (group_index = 0; group_index < LEFTOVER; group_index = group_index + 1) begin : pass_through
            assign rows_out[(2*GROUPS+group_index)*WIDTH +: WIDTH] =
                rows_in[(3*GROUPS+group_index)*WIDTH +: WIDTH];
        end
    endgenerate
endmodule
