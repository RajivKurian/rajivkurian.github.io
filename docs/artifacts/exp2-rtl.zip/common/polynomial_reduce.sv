// Reduce rows until only a carry-save pair remains. The recursive elaboration
// makes the tree shape follow the chosen multiplier widths.
module polynomial_reduce #(
    parameter integer WIDTH = 39,
    parameter integer ROWS = 8
) (
    input wire [ROWS*WIDTH-1:0] rows_in,
    output wire [2*WIDTH-1:0] rows_out
);
    generate
        if (ROWS == 2) begin : pair
            assign rows_out = rows_in;
        end else begin : reduce
            localparam integer NEXT = 2*(ROWS/3)+ROWS%3;
            wire [NEXT*WIDTH-1:0] next_rows;
            carry_save_layer #(.WIDTH(WIDTH), .INPUT_ROWS(ROWS))
                layer(rows_in, next_rows);
            polynomial_reduce #(.WIDTH(WIDTH), .ROWS(NEXT))
                rest(next_rows, rows_out);
        end
    endgenerate
endmodule

