// Unsigned radix-4 Booth rows for the polynomial multipliers. The coefficient
// or first-stage result is recoded; the 20-bit residual is the multiplicand.
// Flipping each row's sign bit replaces replicated sign-extension columns.
// A fixed bias and the two's-complement correction bits restore the same sum.
module booth_rows #(
    parameter integer A_WIDTH = 20,
    parameter integer B_WIDTH = 18,
    parameter integer SUM_WIDTH = 39,
    parameter integer GROUPS = (B_WIDTH + 2) / 2
) (
    input wire [A_WIDTH-1:0] a,
    input wire [B_WIDTH-1:0] b,
    output wire [(GROUPS+1)*SUM_WIDTH-1:0] rows
);
    wire [2*GROUPS:0] extended_b =
        {{(2*GROUPS-B_WIDTH){1'b0}}, b, 1'b0};
    wire [GROUPS-1:0] negative;
    genvar i;
    generate
        for (i = 0; i < GROUPS; i = i + 1) begin : digit
            wire [2:0] triple = extended_b[2*i +: 3];
            wire one = triple[1] ^ triple[0];
            wire two = (triple[2] ^ triple[1]) & ~one;
            assign negative[i] = triple[2];
            wire [A_WIDTH:0] magnitude =
                ({1'b0, a} & {(A_WIDTH+1){one}}) |
                ({a, 1'b0} & {(A_WIDTH+1){two}});
            wire [A_WIDTH+1:0] encoded =
                {~negative[i], magnitude ^ {(A_WIDTH+1){negative[i]}}};
            assign rows[i*SUM_WIDTH +: SUM_WIDTH] =
                {{(SUM_WIDTH-A_WIDTH-2){1'b0}}, encoded} << (2*i);
        end
    endgenerate
    function automatic [SUM_WIDTH-1:0] bias_value;
        integer j;
        begin
            bias_value = 0;
            for (j = 0; j < GROUPS; j = j + 1)
                bias_value = bias_value - (SUM_WIDTH'(1) << (A_WIDTH+1+2*j));
        end
    endfunction
    localparam [SUM_WIDTH-1:0] BIAS = bias_value();
    wire [SUM_WIDTH-1:0] correction;
    generate
        for (i = 0; i < SUM_WIDTH; i = i + 1) begin : correction_bit
            if (i % 2 == 0 && i / 2 < GROUPS) begin : negative_digit
                assign correction[i] = negative[i/2];
            end else begin : zero
                assign correction[i] = 1'b0;
            end
        end
    endgenerate
    // For our A_WIDTH >= B_WIDTH instances these fields do not overlap:
    // correction occupies bits 0..B_WIDTH, while BIAS starts at A_WIDTH+1.
    assign rows[GROUPS*SUM_WIDTH +: SUM_WIDTH] = correction | BIAS;
endmodule
