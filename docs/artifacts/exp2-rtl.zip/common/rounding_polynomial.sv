// The same five-cycle fused-Booth architecture for every rounding experiment.
// Binary points match Exp2Config, so refitted integer tables can be transferred
// without changing the arithmetic. The experiment profiles have product
// scales finer than their addend scales and R >= A,S.
module rounding_polynomial #(
    parameter integer K = 7,
    parameter integer A = 10,
    parameter integer B = 13,
    parameter integer C = 23,
    parameter integer R = 20,
    parameter integer S = 18,
    parameter integer M = 25,
    parameter integer FIRST_RNE = 1,
    parameter integer FINAL_RNE = 1,
    parameter integer FA = A+2*K,
    parameter integer FB = B+K-1,
    parameter integer FS = S+K-1,
    parameter integer FC = C-1,
    parameter integer SHIFT_B = FA+R-FB,
    parameter integer SHIFT_C = FS+R-FC,
    parameter integer W1 = ((A+R > B+SHIFT_B) ? A+R : B+SHIFT_B)+1,
    parameter integer W2 = ((S+R > C+SHIFT_C) ? S+R : C+SHIFT_C)+1,
    parameter integer DROP1 = FA+R-FS,
    parameter integer DROP2 = FS+R-(M-2),
    parameter integer H1 = W1-DROP1,
    parameter integer H2 = W2-DROP2
) (
    input wire clk, reset, in_valid,
    input wire [A-1:0] a,
    input wire [B-1:0] b,
    input wire [C-1:0] c,
    input wire [R-1:0] x,
    output reg out_valid,
    output reg [M-1:0] y
);
    localparam integer G1 = (A+2)/2;
    localparam integer G2 = (S+2)/2;
    wire [(G1+1)*W1-1:0] first_booth;
    booth_rows #(.A_WIDTH(R), .B_WIDTH(A), .SUM_WIDTH(W1))
        first_rows(x, a, first_booth);
    wire [(G1+2)*W1-1:0] first_heap;
    assign first_heap = {first_booth, {{(W1-B-SHIFT_B){1'b0}}, b, {SHIFT_B{1'b0}}}};
    wire [2*W1-1:0] first_pair;
    polynomial_reduce #(.WIDTH(W1), .ROWS(G1+2))
        first_tree(first_heap, first_pair);
    wire [DROP1:0] first_low = {1'b0, first_pair[0 +: DROP1]} +
                                 {1'b0, first_pair[W1 +: DROP1]};
    reg [2*H1-1:0] saved_first;
    reg carry1, guard1, sticky1, valid1;
    reg [R-1:0] x1;
    reg [C-1:0] c1;
    wire [H1-1:0] upper1 = saved_first[0 +: H1] + saved_first[H1 +: H1] +
                             {{(H1-1){1'b0}}, carry1};
    wire round1 = (FIRST_RNE != 0) && guard1 && (sticky1 || upper1[0]);
    wire [H1-1:0] unused_rounded1 = upper1 + {{(H1-1){1'b0}}, round1};
    reg [S-1:0] first;
    reg [R-1:0] x2;
    reg [C-1:0] c2;
    reg valid2;

    wire [(G2+1)*W2-1:0] second_booth;
    booth_rows #(.A_WIDTH(R), .B_WIDTH(S), .SUM_WIDTH(W2))
        second_rows(x2, first, second_booth);
    wire [(G2+2)*W2-1:0] second_heap;
    assign second_heap = {second_booth, {{(W2-C-SHIFT_C){1'b0}}, c2, {SHIFT_C{1'b0}}}};
    wire [2*W2-1:0] second_pair;
    polynomial_reduce #(.WIDTH(W2), .ROWS(G2+2))
        second_tree(second_heap, second_pair);
    wire [DROP2:0] second_low = {1'b0, second_pair[0 +: DROP2]} +
                                  {1'b0, second_pair[W2 +: DROP2]};
    reg [2*H2-1:0] saved_second;
    reg carry3, guard3, sticky3, valid3;
    wire [H2-1:0] upper2 = saved_second[0 +: H2] + saved_second[H2 +: H2] +
                             {{(H2-1){1'b0}}, carry3};
    reg [H2-1:0] retained;
    reg guard4, sticky4, valid4;
    wire round2 = (FINAL_RNE != 0) && guard4 && (sticky4 || retained[0]);
    wire [H2-1:0] rounded2 = retained + {{(H2-1){1'b0}}, round2};

    // Resolve exact low carries before storage. Truncating a stage eliminates
    // its guard/sticky and increment cone through constant propagation.
    always @(posedge clk) begin
        saved_first <= {first_pair[W1+DROP1 +: H1], first_pair[DROP1 +: H1]};
        carry1 <= first_low[DROP1];
        guard1 <= first_low[DROP1-1];
        sticky1 <= |first_low[DROP1-2:0];
        x1 <= x;
        c1 <= c;
        first <= unused_rounded1[S-1:0];
        x2 <= x1;
        c2 <= c1;
        saved_second <= {second_pair[W2+DROP2 +: H2], second_pair[DROP2 +: H2]};
        carry3 <= second_low[DROP2];
        guard3 <= second_low[DROP2-1];
        sticky3 <= |second_low[DROP2-2:0];
        retained <= upper2;
        guard4 <= guard3;
        sticky4 <= sticky3;
        if (reset) begin
            valid1 <= 0;
            valid2 <= 0;
            valid3 <= 0;
            valid4 <= 0;
            out_valid <= 0;
            y <= 0;
        end else begin
            valid1 <= in_valid;
            valid2 <= valid1;
            valid3 <= valid2;
            valid4 <= valid3;
            out_valid <= valid4;
            y <= rounded2[M-1:0];
        end
    end
endmodule
