Part 4 RTL and frozen measurements

Each design folder contains a separate top named sfu_poly; compile one at a time
with common/*.sv. Both use common/polynomial.sdc. Cell libraries and tools come
from the pinned research checkout.

From code/ with its pinned environment active:
  ./scripts/bazel.py build //rtl/rounding:narrow256_s15_tt //rtl/rounding:narrow256_combined_rne
  ./scripts/bazel.py test //rtl/rounding:narrow256_s15_tt_test //rtl/rounding:narrow256_s15_tt_gate_test
  ./scripts/bazel.py test //rtl/rounding:narrow256_combined_rne_test //rtl/rounding:narrow256_combined_rne_gate_test

Reports cover mapped coefficient lookup and polynomial arithmetic. Numerical
FP32 reconstruction and range reduction are evaluated by the full reference model.
